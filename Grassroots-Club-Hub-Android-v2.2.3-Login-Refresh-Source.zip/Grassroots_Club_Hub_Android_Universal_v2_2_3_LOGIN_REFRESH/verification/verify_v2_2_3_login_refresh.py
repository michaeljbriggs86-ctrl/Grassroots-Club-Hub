from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
cloud=(root/'app/src/main/assets/cloud.js').read_text()
index=(root/'app/src/main/assets/index.html').read_text()
gradle=(root/'app/build.gradle').read_text()
main=(root/'app/src/main/java/com/grassrootsclubhub/universal/MainActivity.java').read_text()
onboarding=(root/'app/src/main/assets/onboarding.js').read_text()
edge=(root/'pending_backend_not_deployed/player-access/index.ts').read_text()
sql=(root/'pending_backend_not_deployed/20260919_player_access_credentials.sql').read_text()
checks={
 'versionCode 2203': 'versionCode 2203' in gradle,
 "versionName 2.2.3": "versionName '2.2.3'" in gradle,
 'native UA 2.2.3': 'GrassrootsClubHub/2.2.3' in main,
 'static feed still referenced': '<script src="static-feed-overlay.js"></script>' in index,
 'default adult sign-in': "setGateHtml('signin')" in cloud and "title:'Welcome Back'" in cloud,
 'adult roles copy': 'Admins, Coaches and Parents sign in with email and password.' in cloud,
 'player login separate': "title:'Player Access'" in cloud and 'Player Name' in cloud and 'Player Code' in cloud,
 'player reusable-code explanation': 'reusable code provided by their coach or club' in cloud,
 'club signup separate': "title:'Create Club Account'" in cloud and 'Club Name' in cloud and 'cloud-club-league' in cloud,
 'club signup prefills onboarding': 'admin_email:email' in cloud and 'admin_password:password' in cloud and 'function open(prefill={})' in onboarding,
 'client U15 gate': "Number(context?.team?.age_group||0)!==15" in cloud,
 'player access endpoint': "/functions/v1/player-access" in cloud,
 'server U15 gate': 'Number(team.age_group) !== 15' in edge,
 'server adult issuer roles': '"club_admin", "coach", "assistant_coach"' in edge,
 'no player contact input': all(x not in edge for x in ['player_phone','player_email']),
 'raw player code not stored': 'code_hash' in sql and ('raw code is never stored' in sql.lower() or 'raw access codes are never stored' in sql.lower()),
 'RLS on credential table': 'enable row level security' in sql.lower() and 'revoke all on table public.player_access_credentials from anon, authenticated' in sql.lower(),
 'backend marked not deployed': 'STATUS: WRITTEN 2026-09-19. NOT DEPLOYED' in edge,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), '-', k)
if failed:
    print('\nFAILED:', ', '.join(failed), file=sys.stderr)
    sys.exit(1)
print(f'\n{len(checks)}/{len(checks)} structural checks passed.')
