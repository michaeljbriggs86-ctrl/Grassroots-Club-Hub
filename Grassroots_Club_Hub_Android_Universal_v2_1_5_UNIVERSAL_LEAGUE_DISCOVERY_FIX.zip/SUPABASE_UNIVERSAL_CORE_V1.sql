-- Universal Core v1: club configuration, competition rules and provider abstraction.

create table if not exists public.club_settings (
  club_id uuid primary key references public.clubs(id) on delete cascade,
  slug text not null unique,
  display_name text not null,
  short_name text not null default '',
  primary_color text not null default '#218a21' check (primary_color ~ '^#[0-9A-Fa-f]{6}$'),
  secondary_color text not null default '#ffffff' check (secondary_color ~ '^#[0-9A-Fa-f]{6}$'),
  accent_color text not null default '#218a21' check (accent_color ~ '^#[0-9A-Fa-f]{6}$'),
  logo_asset text not null default 'club-logo.png',
  logo_url text,
  current_season text not null default '2026/27',
  timezone text not null default 'Europe/London',
  country_code text not null default 'GB',
  default_provider_key text not null default 'manual',
  results_publish_from_age integer,
  player_account_age_groups integer[] not null default '{}'::integer[],
  is_demo boolean not null default false,
  active boolean not null default true,
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.competition_rules (
  club_id uuid not null references public.clubs(id) on delete cascade,
  age_group integer not null check (age_group between 5 and 18),
  format text not null,
  players_on_pitch integer not null check (players_on_pitch > 0),
  max_registered integer not null check (max_registered >= players_on_pitch),
  matchday_max integer not null check (matchday_max >= players_on_pitch),
  rolling_substitutions boolean not null default false,
  results_published boolean not null default false,
  player_accounts_allowed boolean not null default false,
  stats_config jsonb not null default '{"goals":true,"assists":true,"awards":true,"bookings":true}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (club_id, age_group)
);

create table if not exists public.competition_providers (
  club_id uuid not null references public.clubs(id) on delete cascade,
  provider_key text not null,
  provider_type text not null,
  enabled boolean not null default true,
  is_primary boolean not null default false,
  config jsonb not null default '{}'::jsonb,
  last_sync_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (club_id, provider_key)
);

create unique index if not exists competition_providers_one_primary
  on public.competition_providers(club_id) where is_primary;

alter table public.club_settings enable row level security;
alter table public.competition_rules enable row level security;
alter table public.competition_providers enable row level security;

drop policy if exists club_settings_read on public.club_settings;
create policy club_settings_read on public.club_settings
for select to authenticated
using (club_id = public.my_club_id());

drop policy if exists club_settings_admin_update on public.club_settings;
create policy club_settings_admin_update on public.club_settings
for update to authenticated
using (club_id = public.my_club_id() and public.my_role() = 'club_admin')
with check (club_id = public.my_club_id() and public.my_role() = 'club_admin');

drop policy if exists competition_rules_read on public.competition_rules;
create policy competition_rules_read on public.competition_rules
for select to authenticated
using (club_id = public.my_club_id());

drop policy if exists competition_rules_admin_write on public.competition_rules;
create policy competition_rules_admin_write on public.competition_rules
for all to authenticated
using (club_id = public.my_club_id() and public.my_role() = 'club_admin')
with check (club_id = public.my_club_id() and public.my_role() = 'club_admin');

drop policy if exists competition_providers_read on public.competition_providers;
create policy competition_providers_read on public.competition_providers
for select to authenticated
using (club_id = public.my_club_id());

drop policy if exists competition_providers_admin_write on public.competition_providers;
create policy competition_providers_admin_write on public.competition_providers
for all to authenticated
using (club_id = public.my_club_id() and public.my_role() = 'club_admin')
with check (club_id = public.my_club_id() and public.my_role() = 'club_admin');

grant select on public.club_settings, public.competition_rules, public.competition_providers to authenticated;
grant insert, update, delete on public.competition_rules, public.competition_providers to authenticated;
grant update on public.club_settings to authenticated;

create or replace function public.get_my_club_configuration()
returns jsonb
language plpgsql
stable
security definer
set search_path = 'public'
as $$
declare
  me public.profiles;
  result jsonb;
begin
  select * into me from public.profiles where user_id = auth.uid();
  if me.user_id is null or me.club_id is null then return null; end if;

  select jsonb_build_object(
    'club', to_jsonb(c),
    'settings', to_jsonb(cs),
    'rules', coalesce((select jsonb_agg(to_jsonb(r) order by r.age_group) from public.competition_rules r where r.club_id=me.club_id),'[]'::jsonb),
    'providers', coalesce((select jsonb_agg(to_jsonb(p) order by p.is_primary desc,p.provider_key) from public.competition_providers p where p.club_id=me.club_id and p.enabled=true),'[]'::jsonb),
    'teams', coalesce((select jsonb_agg(to_jsonb(t) order by t.age_group,t.name) from public.teams t where t.club_id=me.club_id and t.active=true),'[]'::jsonb)
  ) into result
  from public.clubs c
  left join public.club_settings cs on cs.club_id=c.id
  where c.id=me.club_id;

  return result;
end $$;

revoke all on function public.get_my_club_configuration() from public, anon;
grant execute on function public.get_my_club_configuration() to authenticated;

create or replace function public.get_demo_club_configuration(p_slug text)
returns jsonb
language plpgsql
stable
security definer
set search_path = 'public'
as $$
declare
  cid uuid;
  result jsonb;
begin
  select club_id into cid from public.club_settings where slug=lower(trim(p_slug)) and is_demo=true and active=true;
  if cid is null then return null; end if;

  select jsonb_build_object(
    'club', jsonb_build_object('id',c.id,'name',c.name),
    'settings', to_jsonb(cs),
    'rules', coalesce((select jsonb_agg(to_jsonb(r) order by r.age_group) from public.competition_rules r where r.club_id=cid),'[]'::jsonb),
    'providers', coalesce((select jsonb_agg(jsonb_build_object('provider_key',p.provider_key,'provider_type',p.provider_type,'enabled',p.enabled,'is_primary',p.is_primary,'config',p.config) order by p.is_primary desc,p.provider_key) from public.competition_providers p where p.club_id=cid and p.enabled=true),'[]'::jsonb),
    'teams', coalesce((select jsonb_agg(jsonb_build_object('id',t.id,'name',t.name,'age_group',t.age_group,'division',t.division,'season',t.season,'selkent_label',t.selkent_label,'league_name',t.league_name,'active',t.active) order by t.age_group,t.name) from public.teams t where t.club_id=cid and t.active=true),'[]'::jsonb)
  ) into result
  from public.clubs c join public.club_settings cs on cs.club_id=c.id
  where c.id=cid;

  return result;
end $$;

grant execute on function public.get_demo_club_configuration(text) to anon, authenticated;

-- Seed Shooters Hill current behaviour into configuration.
insert into public.club_settings(
  club_id,slug,display_name,short_name,primary_color,secondary_color,accent_color,
  logo_asset,current_season,timezone,country_code,default_provider_key,
  results_publish_from_age,player_account_age_groups,is_demo,config
)
select c.id,'shooters-hill-afc','Shooters Hill AFC','SH AFC','#218a21','#ffffff','#218a21',
       'shooters-hill-logo.png','2026/27','Europe/London','GB','selkent',12,array[15]::integer[],false,
       jsonb_build_object('sport','football','results_visibility','provider','player_profiles','U15 only','kit_colours','Green and White')
from public.clubs c
where c.name='Shooters Hill Football Club'
on conflict (club_id) do update set
  slug=excluded.slug,display_name=excluded.display_name,short_name=excluded.short_name,
  primary_color=excluded.primary_color,secondary_color=excluded.secondary_color,accent_color=excluded.accent_color,
  current_season=excluded.current_season,default_provider_key=excluded.default_provider_key,
  results_publish_from_age=excluded.results_publish_from_age,player_account_age_groups=excluded.player_account_age_groups,
  config=excluded.config,updated_at=now();

insert into public.competition_providers(club_id,provider_key,provider_type,enabled,is_primary,config)
select c.id,'selkent','selkent',true,true,
       jsonb_build_object(
         'club_url',coalesce(c.selkent_club_url,'https://www.selkent.org.uk/public/clubs/499'),
         'divisions_url','https://www.selkent.org.uk/public/divisions/all',
         'fixtures_url','https://www.selkent.org.uk/public/fixtures/all',
         'results_url','https://www.selkent.org.uk/public/results',
         'directory_url','https://www.selkent.org.uk/public/clubs/directory'
       )
from public.clubs c where c.name='Shooters Hill Football Club'
on conflict (club_id,provider_key) do update set enabled=true,is_primary=true,config=excluded.config,updated_at=now();

with sh as (select id from public.clubs where name='Shooters Hill Football Club')
insert into public.competition_rules(club_id,age_group,format,players_on_pitch,max_registered,matchday_max,rolling_substitutions,results_published,player_accounts_allowed,stats_config)
select sh.id,v.age_group,v.format,v.on_pitch,v.reg_max,v.match_max,v.rolling,(v.age_group>=12),(v.age_group=15),
       '{"goals":true,"assists":true,"awards":true,"bookings":true}'::jsonb
from sh cross join (values
  (8,'5v5',5,10,10,true),(9,'5v5',5,10,10,true),(10,'7v7',7,14,14,true),(11,'7v7',7,14,14,true),
  (12,'9v9',9,16,14,false),(13,'9v9',9,16,14,false),(14,'11v11',11,18,16,false),(15,'11v11',11,18,16,false),
  (16,'11v11',11,18,16,false),(17,'11v11',11,18,16,false)
) as v(age_group,format,on_pitch,reg_max,match_max,rolling)
on conflict (club_id,age_group) do update set
  format=excluded.format,players_on_pitch=excluded.players_on_pitch,max_registered=excluded.max_registered,
  matchday_max=excluded.matchday_max,rolling_substitutions=excluded.rolling_substitutions,
  results_published=excluded.results_published,player_accounts_allowed=excluded.player_accounts_allowed,
  stats_config=excluded.stats_config,updated_at=now();

-- Create a second isolated demo tenant to prove configuration-driven behaviour.
do $$
declare demo_id uuid;
begin
  select id into demo_id from public.clubs where name='Greenwich United FC' order by created_at limit 1;
  if demo_id is null then
    insert into public.clubs(name,selkent_club_url) values('Greenwich United FC',null) returning id into demo_id;
  end if;

  insert into public.club_settings(
    club_id,slug,display_name,short_name,primary_color,secondary_color,accent_color,logo_asset,
    current_season,timezone,country_code,default_provider_key,results_publish_from_age,
    player_account_age_groups,is_demo,config
  ) values(
    demo_id,'greenwich-united-demo','Greenwich United FC','GUFC','#1756a9','#f4c430','#1756a9','',
    '2026/27','Europe/London','GB','manual',11,'{}'::integer[],true,
    '{"sport":"football","results_visibility":"club-defined","player_profiles":"disabled","kit_colours":"Blue and Yellow"}'::jsonb
  ) on conflict (club_id) do update set
    display_name=excluded.display_name,short_name=excluded.short_name,primary_color=excluded.primary_color,
    secondary_color=excluded.secondary_color,accent_color=excluded.accent_color,default_provider_key=excluded.default_provider_key,
    results_publish_from_age=excluded.results_publish_from_age,player_account_age_groups=excluded.player_account_age_groups,
    is_demo=true,config=excluded.config,updated_at=now();

  insert into public.competition_providers(club_id,provider_key,provider_type,enabled,is_primary,config)
  values(demo_id,'manual','manual',true,true,'{"fixtures":"manual","results":"manual"}'::jsonb)
  on conflict (club_id,provider_key) do update set enabled=true,is_primary=true,config=excluded.config,updated_at=now();

  insert into public.competition_rules(club_id,age_group,format,players_on_pitch,max_registered,matchday_max,rolling_substitutions,results_published,player_accounts_allowed,stats_config)
  values
    (demo_id,9,'5v5',5,9,9,true,false,false,'{"goals":true,"assists":false,"awards":true,"bookings":false}'::jsonb),
    (demo_id,11,'7v7',7,12,12,true,true,false,'{"goals":true,"assists":true,"awards":true,"bookings":false}'::jsonb),
    (demo_id,13,'9v9',9,16,14,false,true,false,'{"goals":true,"assists":true,"awards":true,"bookings":true}'::jsonb),
    (demo_id,15,'11v11',11,18,16,false,true,false,'{"goals":true,"assists":true,"awards":true,"bookings":true}'::jsonb)
  on conflict (club_id,age_group) do update set
    format=excluded.format,players_on_pitch=excluded.players_on_pitch,max_registered=excluded.max_registered,
    matchday_max=excluded.matchday_max,rolling_substitutions=excluded.rolling_substitutions,
    results_published=excluded.results_published,player_accounts_allowed=excluded.player_accounts_allowed,
    stats_config=excluded.stats_config,updated_at=now();

  insert into public.teams(club_id,name,age_group,division,season,selkent_label,league_name,active)
  select demo_id,x.name,x.age_group,'','2026/27',x.label,x.league_name,true
  from (values
    ('Comets',9,'Under 9s Comets','Greenwich United FC Comets'),
    ('Falcons',11,'Under 11s Falcons','Greenwich United FC Falcons'),
    ('Rovers',13,'Under 13s Rovers','Greenwich United FC Rovers'),
    ('Athletic',15,'Under 15s Athletic','Greenwich United FC Athletic')
  ) as x(name,age_group,label,league_name)
  where not exists (
    select 1 from public.teams t where t.club_id=demo_id and t.name=x.name and t.age_group=x.age_group
  );
end $$;
