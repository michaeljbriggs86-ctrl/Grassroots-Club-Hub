LEGACY REFERENCE — DO NOT DEPLOY

These files came from earlier universal/national prototypes and are retained only for project history.
They are not the production backend for Grassroots Club Hub v2.2.1.

v2.2.1 is deliberately scoped to Selkent for automatic competition data.
The live Supabase project already contains the current compliance/retention/Selkent implementation.
Do not redeploy these older SQL/Edge files over the live project.
