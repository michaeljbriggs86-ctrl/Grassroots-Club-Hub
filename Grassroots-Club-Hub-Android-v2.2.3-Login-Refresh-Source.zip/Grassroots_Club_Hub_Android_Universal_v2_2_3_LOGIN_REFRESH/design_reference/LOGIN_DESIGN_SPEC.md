# Login design specification — approved 2026-09-19

**Status:** Active visual specification for the v2.2.3 login refresh.

Reference image: `APPROVED_LOGIN_MOCKUP_2026-09-19.png`

The implementation must follow this theme rather than falling back to the legacy dark/card login UI.

## Screen family

1. **Adult Login** — default opening screen for Club Admins, Coaches and Parents.
2. **Player Login** — separate Player Name + Player Code screen; no player email/contact field.
3. **Club Sign Up** — separate Create Club Account entry which continues into onboarding.

## Visual rules

- White/light canvas with Grassroots Club Hub green as the primary action colour.
- Shield + football app identity at the top.
- Soft football/grass hero imagery rather than generic dark panels.
- Bold black primary headings and restrained grey supporting copy.
- Rounded, lightly outlined input fields with leading icons.
- Full-width green primary CTA with white text.
- Outlined secondary Player Login action on the adult screen.
- Strong green text links for Club Sign Up / back actions.
- Pale green safeguarding/info panels where shown in the mock-up.
- Grass/football footer treatment at the bottom of the principal auth screens.
- Consistent typography, spacing, radius, icon weight and green/white treatment across all three screens and onboarding continuation.

## Functional boundaries represented by the design

- Adult email/password login is the normal returning route for Admins, Coaches and Parents.
- Player access is a distinct route and remains U15-only under the current product architecture.
- Club sign-up is visible from the opening page.
- Legacy PIN/one-time invite access may remain as a migration path, but it must stay visually subordinate and must not compete with the three approved primary screens.
