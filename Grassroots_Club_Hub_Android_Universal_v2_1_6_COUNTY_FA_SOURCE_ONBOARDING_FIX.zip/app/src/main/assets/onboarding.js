(function(){
  'use strict';
  const CFG=window.VALIANTS_CLOUD||{};
  const SESSION_KEY='shooters_hill_cloud_session_v2';
  const STEPS=['Setup','Club','Brand','Teams','Rules','Admin','Review'];
  const AGE_OPTIONS=Array.from({length:12},(_,i)=>i+7);
  let host=null;
  let providerResults=[];
  let clubResults=[];
  let countyFaResults=[];
  let leagueTeams=[];
  let teamSearchResults=[];
  const state={step:1,setup_mode:'',club_name:'',short_name:'',country_code:'GB',timezone:'Europe/London',season:'2026/27',primary_color:'#218a21',secondary_color:'#ffffff',accent_color:'#218a21',badge:null,provider:{type:'fulltime',key:'fulltime',label:'League discovery',config:{}},teams:[],rules:{},admin_name:'',admin_email:'',admin_password:'',admin_password2:''};

  const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slugify=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,54)||'club';
  const nameKey=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,' ').trim();
  const initials=s=>String(s||'').split(/\s+/).filter(x=>x&&!/^(?:football|club|the)$/i.test(x)).map(x=>x[0]).join('').slice(0,8).toUpperCase();
  function inferAgeText(value=''){const m=String(value||'').match(/(?:^|\b)(?:under\s*|u\s*)(\d{1,2})(?:\b|s\b)/i);const n=m?Number(m[1]):0;return n>=5&&n<=21?n:null;}
  function inferClubName(team={}){
    const raw=String(team.league_name||team.provider_label||team.name||'').replace(/\s+/g,' ').trim();
    const supplied=String(team.club_name||'').replace(/\s+/g,' ').trim();
    if(supplied&&nameKey(supplied)!==nameKey(raw))return supplied;
    let base=raw.replace(/\s+(?:under\s*|u\s*)\d{1,2}s?(?:\s+.*)?$/i,'').trim();
    const marker=base.match(/^(.*?\b(?:AFC|F\.?C\.?|JFC|Youth FC|Football Club|United FC|Town FC|City FC))\b/i);
    if(marker&&marker[1]&&marker[1].trim().split(/\s+/).length>1)base=marker[1].trim();
    return base||raw;
  }
  function teamShortName(team={},club=''){
    const raw=String(team.league_name||team.provider_label||team.name||'').replace(/\s+/g,' ').trim();
    const age=Number(team.age_group)||inferAgeText(raw)||inferAgeText(team.provider_label);
    let out=raw;
    if(club&&nameKey(out).startsWith(nameKey(club))){const words=club.trim().split(/\s+/).length;out=raw.trim().split(/\s+/).slice(words).join(' ').trim();}
    out=out.replace(/^(?:under\s*|u\s*)\d{1,2}s?\s*/i,'').replace(/\s+(?:under\s*|u\s*)\d{1,2}s?$/i,'').trim();
    return out||(age?`U${age}`:String(team.name||raw||'Team').trim());
  }
  function normaliseLeagueTeam(team={}){const full=String(team.league_name||team.name||team.provider_label||'').replace(/\s+/g,' ').trim();return{...team,league_name:full||String(team.name||''),club_name:inferClubName(team),age_group:Number(team.age_group)||inferAgeText(full)||inferAgeText(team.provider_label)||null,selected:true};}
  function filterLeagueTeams(query=''){const q=nameKey(query);const rows=leagueTeams.filter(t=>{if(!q)return true;return [t.league_name,t.name,t.provider_label,inferClubName(t),t.division].some(v=>nameKey(v).includes(q));});const seen=new Set();return rows.filter(t=>{const k=String(t.provider_team_id||'')||nameKey(`${t.league_name}|${t.division}`);if(seen.has(k))return false;seen.add(k);return true;}).slice(0,60);}
  function leagueTeamResultsHtml(){
    if(!state.provider.config.league_loaded)return'';
    if(!leagueTeams.length)return'<div class="provider-summary">No team records were exposed on this Full-Time league page. Try the Full-Time link option for the relevant division or use Manual setup.</div>';
    if(!teamSearchResults.length){const q=state.provider.config.team_search_query||'';return `<div class="provider-summary">${q?'No matching team found. Try part of the club name, team name or age group.':'Search by club or team name to continue.'}</div>`;}
    return teamSearchResults.map((t,i)=>{const club=inferClubName(t),age=Number(t.age_group)||inferAgeText(t.league_name),bits=[club&&nameKey(club)!==nameKey(t.league_name)?club:'',age?`U${age}`:'',t.division||''].filter(Boolean).join(' · ');return `<div class="provider-result team-search-result"><span><strong>${esc(t.league_name||t.name||'Team')}</strong>${bits?`<small>${esc(bits)}</small>`:''}</span><button type="button" data-league-team-result="${i}">Select team</button></div>`;}).join('');
  }
  const apiBase=()=>String(CFG.url||'').replace(/\/$/,'');
  async function edge(name,body){const res=await fetch(`${apiBase()}/functions/v1/${name}`,{method:'POST',headers:{apikey:CFG.anonKey,'Content-Type':'application/json'},body:JSON.stringify(body||{})});const text=await res.text();let data={};try{data=text?JSON.parse(text):{};}catch{data={error:text};}if(!res.ok||data?.error)throw new Error(data?.error||`Request failed (${res.status})`);return data;}
  function defaultRule(age){if(age<=9)return{age_group:age,format:'5v5',players_on_pitch:5,max_registered:10,matchday_max:10,rolling_substitutions:true,results_published:false,player_accounts_allowed:false,stats_config:{goals:true,assists:true,awards:true,bookings:true}};if(age<=11)return{age_group:age,format:'7v7',players_on_pitch:7,max_registered:14,matchday_max:14,rolling_substitutions:true,results_published:false,player_accounts_allowed:false,stats_config:{goals:true,assists:true,awards:true,bookings:true}};if(age<=13)return{age_group:age,format:'9v9',players_on_pitch:9,max_registered:16,matchday_max:14,rolling_substitutions:false,results_published:true,player_accounts_allowed:false,stats_config:{goals:true,assists:true,awards:true,bookings:true}};return{age_group:age,format:'11v11',players_on_pitch:11,max_registered:18,matchday_max:16,rolling_substitutions:false,results_published:true,player_accounts_allowed:false,stats_config:{goals:true,assists:true,awards:true,bookings:true}};}
  function selectedTeams(){return state.teams.filter(t=>t.selected!==false&&String(t.name||'').trim());}
  function syncRules(){const ages=[...new Set(selectedTeams().map(t=>Number(t.age_group)).filter(a=>a>=5&&a<=21))].sort((a,b)=>a-b);const next={};ages.forEach(a=>next[a]=state.rules[a]||defaultRule(a));state.rules=next;}
  function stepProgress(){return `<div class="onboard-progress">${STEPS.map((s,i)=>`<div class="onboard-step ${state.step===i+1?'active':''} ${state.step>i+1?'done':''}"><i>${i+1}</i><span>${s}</span></div>`).join('')}</div>`;}
  function wrap(title,copy,body,{back=true,next='Next',nextDisabled=false}={}){return `<div class="onboard-shell">${stepProgress()}<div class="onboard-main"><button type="button" class="onboard-close" id="onboard-close">← Return to sign in</button><div class="onboard-heading"><p class="kicker">CREATE YOUR CLUB</p><h1>${esc(title)}</h1><p>${esc(copy)}</p></div>${body}<div id="onboard-global-message"></div><div class="onboard-actions">${back?'<button type="button" class="onboard-back" id="onboard-back">Back</button>':'<button type="button" class="onboard-back" id="onboard-cancel">Cancel</button>'}<button type="button" class="onboard-next" id="onboard-next" ${nextDisabled?'disabled':''}>${esc(next)}</button></div></div></div>`;}
  function setupStep(){return wrap('Choose your setup method','Start by choosing whether the app should find your club automatically or you want to enter it yourself.',`<div class="onboard-card"><div class="setup-choice-grid"><button type="button" class="setup-choice ${state.setup_mode==='auto'?'active':''}" data-setup-mode="auto"><strong>Find automatically</strong><span>County FA → league → team → club details.</span></button><button type="button" class="setup-choice ${state.setup_mode==='manual'?'active':''}" data-setup-mode="manual"><strong>Enter manually</strong><span>Type the club and team information yourself.</span></button></div></div>`,{back:false,next:'Continue',nextDisabled:!state.setup_mode});}
  function clubDetailsFields(help=''){return `<div class="onboard-grid"><label class="onboard-field-wide">Club name<input id="ob-club-name" value="${esc(state.club_name)}" placeholder="e.g. Shooters Hill AFC" autocomplete="organization"/>${help?`<span class="onboard-help">${esc(help)}</span>`:''}</label><label>Short name<input id="ob-short-name" value="${esc(state.short_name)}" maxlength="18" placeholder="e.g. SHFC"/></label><label>Season<input id="ob-season" value="${esc(state.season)}" placeholder="2026/27"/></label><label>Country<select id="ob-country"><option value="GB" ${state.country_code==='GB'?'selected':''}>United Kingdom</option><option value="IE" ${state.country_code==='IE'?'selected':''}>Ireland</option><option value="OTHER" ${state.country_code==='OTHER'?'selected':''}>Other</option></select></label><label>Timezone<select id="ob-timezone"><option value="Europe/London" ${state.timezone==='Europe/London'?'selected':''}>Europe/London</option><option value="Europe/Dublin" ${state.timezone==='Europe/Dublin'?'selected':''}>Europe/Dublin</option><option value="UTC" ${state.timezone==='UTC'?'selected':''}>UTC</option></select></label></div>`;}
  function manualClubStep(){return wrap('Club details','Enter the club details manually. You can connect a league provider later from Club Admin settings.',`<div class="onboard-card">${clubDetailsFields()}</div>`);}
  function brandStep(){const preview=state.badge?.dataUrl?`<img src="${state.badge.dataUrl}" alt="Club badge preview"/>`:'Badge',fileName=state.badge?.name||'No badge selected';return wrap('Branding','Upload a badge and choose the colours used throughout the club app.',`<div class="onboard-card"><div class="badge-editor"><div class="badge-preview" id="ob-badge-preview">${preview}</div><div class="badge-file"><label>Club badge</label><input class="badge-file-input" id="ob-badge" type="file" accept="image/png,image/jpeg,image/webp"/><button type="button" class="badge-picker-button" id="ob-badge-picker">Choose badge image</button><span class="badge-file-name" id="ob-badge-name">${esc(fileName)}</span><span class="onboard-help">PNG, JPG or WebP · max 1 MB.</span></div></div><div class="colour-grid"><label class="colour-control">Primary<input id="ob-primary" type="color" value="${esc(state.primary_color)}"/></label><label class="colour-control">Secondary<input id="ob-secondary" type="color" value="${esc(state.secondary_color)}"/></label><label class="colour-control">Accent<input id="ob-accent" type="color" value="${esc(state.accent_color)}"/></label></div><div class="brand-live" id="ob-brand-live" style="--preview-primary:${esc(state.primary_color)};--preview-secondary:${esc(state.secondary_color)}"><strong>${esc(state.club_name||'Your Club')}</strong><small>Live branding preview</small></div></div>`);}
  function leagueResultsHtml(){
    if(!providerResults.length){
      const county=state.provider.config.county_fa_name||'';
      return `<div class="provider-summary">${county?`No leagues were found on the ${esc(county)} website. Try the search box or the Full-Time link fallback below.`:'Choose your County FA and the app will read its own league directory.'}</div>`;
    }
    return providerResults.map((r,i)=>{const providerNote=r.provider==='fulltime'?' · FA Full-Time':r.provider==='selkent'?' · Selkent':' · League website';return `<div class="provider-result"><span><strong>${esc(r.name)}</strong><small>${esc(r.source||'County FA website')}${providerNote}</small></span><button type="button" data-league-result="${i}">Use league</button></div>`;}).join('');
  }
  function providerStep(){
    const t=state.provider.type;
    const county=state.provider.config.county_fa_name||'', countyWebsite=state.provider.config.county_fa_website||'';
    const countyOptions=['<option value="">Choose County FA…</option>',...countyFaResults.map((c,i)=>`<option value="${i}" ${c.name===county?'selected':''}>${esc(c.name)}</option>`)].join('');
    let teamRoute='';
    if(t==='selkent'&&state.provider.config.league_loaded){
      teamRoute=`<div class="provider-route-step provider-team-finder"><strong>3 · Find your club / team</strong><div class="selected-league-line"><span>Selected league</span><b>${esc(state.provider.config.league_name||state.provider.label||'League')}</b></div><div class="provider-search-row"><label>Club or team name<input id="ob-selkent-query" value="${esc(state.provider.config.club_search_query||state.club_name||'')}" placeholder="e.g. Shooters Hill"/></label><button type="button" id="ob-selkent-search">Search teams</button></div><div class="onboard-help">Team data is now read from the selected league after the County FA identifies it.</div><div class="provider-results" id="ob-club-results"></div></div>`;
    }else if(t==='fulltime'&&state.provider.config.league_loaded){
      teamRoute=`<div class="provider-route-step provider-team-finder"><strong>3 · Find your team</strong><div class="selected-league-line"><span>Selected league</span><b>${esc(state.provider.config.league_name||state.provider.label||'FA Full-Time')}</b></div><div class="provider-search-row"><label>Club or team name<input id="ob-league-team-query" value="${esc(state.provider.config.team_search_query||state.club_name||'')}" placeholder="e.g. Shooters Hill or Valiants"/></label><button type="button" id="ob-league-team-search">Search teams</button></div><div class="onboard-help">Select one of your teams. The app will identify the club and add the other teams it can match in this league.</div><div class="provider-results team-search-results" id="ob-team-search-results">${leagueTeamResultsHtml()}</div></div>`;
    }else if(t==='external'&&state.provider.config.league_loaded){
      teamRoute=`<div class="provider-route-step provider-team-finder"><strong>3 · Confirm your club</strong><div class="selected-league-line"><span>Selected league</span><b>${esc(state.provider.config.league_name||state.provider.label||'League')}</b></div><div class="onboard-help">This County FA lists the league on its own website, but its team directory is not exposed through FA Full-Time or a supported public feed. Enter the club name here, then add/review teams on the next screen.</div>${clubDetailsFields('League selected from the County FA website.')}</div>`;
    }
    const setup=`<div class="provider-route">
      <div class="provider-route-step"><strong>1 · County FA</strong><label>County FA<select id="ob-county-fa">${countyOptions}</select></label><div id="ob-county-status" class="onboard-help">${countyFaResults.length?`${countyFaResults.length} County FAs loaded from The FA.`:'Loading The FA County FA directory…'}</div>${countyWebsite?`<div class="provider-source-link">League source: ${esc(countyWebsite)}</div>`:''}</div>
      <div class="provider-route-step"><strong>2 · Choose league</strong><div id="ob-league-status" class="onboard-help">${county?`Reading leagues from the ${esc(county)} website…`:'Choose a County FA first.'}</div><div class="provider-search-row"><label>Filter leagues <span class="optional">optional</span><input id="ob-fulltime-query" value="${esc(state.provider.config.league_search_query||'')}" placeholder="e.g. youth, Sunday, women"/></label><button type="button" id="ob-fulltime-search">Filter</button></div><div class="provider-results" id="ob-provider-results">${leagueResultsHtml()}</div></div>
      ${teamRoute}
      <details class="provider-advanced"><summary>Can't find your league?</summary><div class="provider-search-row"><label>FA Full-Time league / division URL<input id="ob-fulltime-url" type="url" value="${esc(state.provider.config.league_url||'')}" placeholder="https://fulltime.thefa.com/index.html?league=…"/></label><button type="button" id="ob-fulltime-read">Use link</button></div></details>
    </div>`;
    let summary='';
    if(state.provider.imported){const count=selectedTeams().length||state.teams.length;summary=`<div class="provider-summary provider-success-summary"><strong>${esc(state.club_name||'Club found')}</strong>${count} team${count===1?'':'s'} ready to review · ${esc(state.provider.label||'League information loaded')}</div><div class="provider-route-step club-confirm-step"><strong>4 · Confirm club details</strong>${clubDetailsFields('These details were filled from the league where possible. Check them before continuing.')}</div>`;}
    else if(t==='external'&&state.provider.config.league_loaded)summary='';
    else if(state.provider.config.league_loaded)summary=`<div class="provider-summary"><strong>League selected</strong>Now find and select your club/team above so the remaining setup can be filled automatically.</div>`;
    return wrap('Find your club','Choose your County FA first. League choices are then read from that County FA website, not from a global Selkent or Full-Time default list.',`<div class="onboard-card">${setup}${summary}<div id="ob-provider-message"></div></div>`);
  }
  function ageSelect(age){return `<select class="team-age">${['<option value="">Age…</option>',...AGE_OPTIONS.map(a=>`<option value="${a}" ${Number(age)===a?'selected':''}>U${a}</option>`)].join('')}</select>`;}
  function teamsStep(){const rows=state.teams.map((t,i)=>`<div class="team-row" data-team-index="${i}"><input class="team-selected" type="checkbox" ${t.selected!==false?'checked':''} aria-label="Use team"/><input class="team-name" value="${esc(t.name||'')}" placeholder="Team name"/>${ageSelect(t.age_group)}<input class="team-division" value="${esc(t.division||'')}" placeholder="Division (optional)"/><button type="button" class="remove-team" aria-label="Remove team">×</button></div>`).join('');return wrap('Teams','Review the teams found for your club. Confirm age groups and divisions, untick teams you do not want, or add another team manually.',`<div class="onboard-card"><div class="team-head"><span>Use</span><span>Team</span><span>Age</span><span>Division</span><span></span></div><div class="team-list" id="ob-team-list">${rows||'<p class="onboard-help">No teams imported yet. Add your first team below.</p>'}</div><div class="team-add"><label>Team name<input id="ob-add-team-name" placeholder="e.g. Valiants"/></label><label>Age<select id="ob-add-team-age">${AGE_OPTIONS.map(a=>`<option value="${a}" ${a===9?'selected':''}>U${a}</option>`).join('')}</select></label><label class="add-division">Division<input id="ob-add-team-division" placeholder="Optional"/></label><button type="button" id="ob-add-team">Add team</button></div></div>`);}
  function rulesStep(){syncRules();const cards=Object.values(state.rules).map(r=>`<div class="onboard-rule-card" data-rule-age="${r.age_group}"><div class="rule-title"><strong>U${r.age_group}</strong><span class="onboard-help">Applies to all U${r.age_group} teams</span></div><div class="rule-fields"><label>Format<select class="rule-format">${['5v5','7v7','9v9','11v11'].map(f=>`<option ${r.format===f?'selected':''}>${f}</option>`).join('')}</select></label><label>On pitch<input class="rule-on" type="number" min="1" max="11" value="${r.players_on_pitch}"/></label><label>Registered<input class="rule-reg" type="number" min="1" max="40" value="${r.max_registered}"/></label><label>Matchday<input class="rule-match" type="number" min="1" max="30" value="${r.matchday_max}"/></label></div><div class="rule-toggles"><label class="rule-toggle"><input class="rule-rolling" type="checkbox" ${r.rolling_substitutions?'checked':''}/><span>Rolling substitutions</span></label><label class="rule-toggle"><input class="rule-results" type="checkbox" ${r.results_published?'checked':''}/><span>Publish results</span></label><label class="rule-toggle"><input class="rule-player" type="checkbox" ${r.player_accounts_allowed?'checked':''}/><span>Player accounts</span></label></div></div>`).join('');return wrap('Football rules','Defaults are based on the age groups you added. Adjust anything that differs in your league or competition.',`<div class="rules-list">${cards}</div>`);}
  function adminStep(){return wrap('Club Admin','Create the first administrator for this club. This account can invite coaches and manage club settings.',`<div class="onboard-card"><div class="onboard-grid"><label class="onboard-field-wide">Full name<input id="ob-admin-name" value="${esc(state.admin_name)}" autocomplete="name"/></label><label class="onboard-field-wide">Email<input id="ob-admin-email" type="email" value="${esc(state.admin_email)}" autocomplete="email" autocapitalize="none"/></label><label>Password<input id="ob-admin-password" type="password" value="${esc(state.admin_password)}" autocomplete="new-password"/></label><label>Confirm password<input id="ob-admin-password2" type="password" value="${esc(state.admin_password2)}" autocomplete="new-password"/></label></div><p class="onboard-help" style="margin-top:10px">Use at least 8 characters. This becomes the Club Admin sign-in.</p></div>`);}
  function reviewStep(){syncRules();const teams=selectedTeams(),provider=state.provider.label||({selkent:'Selkent',fulltime:'FA Full-Time',manual:'Manual'}[state.provider.type]||state.provider.type);return wrap('Review & create','Check the setup below. You can change these settings later from Club Admin.',`<div class="onboard-card review-list"><div class="review-row"><span>Club</span><strong>${esc(state.club_name)} · ${esc(state.season)}</strong></div><div class="review-row"><span>Provider</span><strong>${esc(provider)}</strong></div><div class="review-row"><span>Teams</span><div class="review-team-chips">${teams.map(t=>`<i>U${t.age_group} ${esc(t.name)}</i>`).join('')}</div></div><div class="review-row"><span>Branding</span><strong><span style="display:inline-block;width:14px;height:14px;border-radius:4px;background:${esc(state.primary_color)};vertical-align:-2px"></span> ${esc(state.primary_color)} / ${esc(state.secondary_color)}</strong></div><div class="review-row"><span>Club Admin</span><strong>${esc(state.admin_name)} · ${esc(state.admin_email)}</strong></div></div><p class="onboard-help" style="text-align:center;margin-top:12px;color:#b9cbbf">Creating the club will sign you in as its first Club Admin.</p>`,{next:'Create club'});}
  function render(){if(!host)return;let html='';if(state.step===1)html=setupStep();if(state.step===2)html=state.setup_mode==='manual'?manualClubStep():providerStep();if(state.step===3)html=brandStep();if(state.step===4)html=teamsStep();if(state.step===5)html=rulesStep();if(state.step===6)html=adminStep();if(state.step===7)html=reviewStep();host.innerHTML=html;bind();}
  function message(text,error=true,target='onboard-global-message'){const el=document.getElementById(target);if(el)el.innerHTML=text?`<div class="onboard-error ${error?'':'onboard-success'}">${esc(text)}</div>`:'';}
  function saveClubFields(){state.club_name=document.getElementById('ob-club-name')?.value.trim()||state.club_name||'';state.short_name=document.getElementById('ob-short-name')?.value.trim()||state.short_name||'';state.season=document.getElementById('ob-season')?.value.trim()||state.season||'';state.country_code=document.getElementById('ob-country')?.value||state.country_code||'GB';state.timezone=document.getElementById('ob-timezone')?.value||state.timezone||'Europe/London';if(!state.short_name&&state.club_name)state.short_name=initials(state.club_name);}
  function saveStep(){
    if(state.step===2)saveClubFields();
    if(state.step===3){state.primary_color=document.getElementById('ob-primary')?.value||state.primary_color;state.secondary_color=document.getElementById('ob-secondary')?.value||state.secondary_color;state.accent_color=document.getElementById('ob-accent')?.value||state.accent_color;}
    if(state.step===4){document.querySelectorAll('[data-team-index]').forEach(row=>{const i=Number(row.dataset.teamIndex),t=state.teams[i];if(!t)return;t.selected=row.querySelector('.team-selected')?.checked!==false;t.name=row.querySelector('.team-name')?.value.trim()||'';t.age_group=Number(row.querySelector('.team-age')?.value||0)||null;t.division=row.querySelector('.team-division')?.value.trim()||'';});}
    if(state.step===5){document.querySelectorAll('[data-rule-age]').forEach(card=>{const age=Number(card.dataset.ruleAge),r=state.rules[age];if(!r)return;r.format=card.querySelector('.rule-format')?.value||r.format;r.players_on_pitch=Number(card.querySelector('.rule-on')?.value||r.players_on_pitch);r.max_registered=Number(card.querySelector('.rule-reg')?.value||r.max_registered);r.matchday_max=Number(card.querySelector('.rule-match')?.value||r.matchday_max);r.rolling_substitutions=!!card.querySelector('.rule-rolling')?.checked;r.results_published=!!card.querySelector('.rule-results')?.checked;r.player_accounts_allowed=!!card.querySelector('.rule-player')?.checked;});}
    if(state.step===6){state.admin_name=document.getElementById('ob-admin-name')?.value.trim()||'';state.admin_email=document.getElementById('ob-admin-email')?.value.trim()||'';state.admin_password=document.getElementById('ob-admin-password')?.value||'';state.admin_password2=document.getElementById('ob-admin-password2')?.value||'';}
  }
  function validate(){
    if(state.step===1&&!state.setup_mode)return'Choose Find automatically or Enter manually.';
    if(state.step===2){
      if(state.setup_mode==='manual'){if(state.club_name.length<3)return'Enter the club name.';if(!state.season)return'Enter the current season.';}
      else{
        if(state.provider.type==='external'&&state.provider.config.league_loaded){if(state.club_name.length<3)return'Enter your club name for this league before continuing.';if(!state.season)return'Enter the current season.';}
        else if(!state.provider.imported)return'Select a league, then find and select your club/team before continuing.';
        else{if(state.club_name.length<3)return'Check the club name before continuing.';if(!state.season)return'Enter the current season.';}
      }
    }
    if(state.step===4){const teams=selectedTeams();if(!teams.length)return'Add or select at least one team.';if(teams.some(t=>!Number(t.age_group)))return'Set an age group for every selected team.';}
    if(state.step===5){for(const r of Object.values(state.rules)){if(r.players_on_pitch<1||r.max_registered<r.players_on_pitch||r.matchday_max<r.players_on_pitch)return`Check the U${r.age_group} squad limits.`;}}
    if(state.step===6){if(state.admin_name.length<2)return'Enter the Club Admin name.';if(!/^\S+@\S+\.\S+$/.test(state.admin_email))return'Enter a valid Club Admin email.';if(state.admin_password.length<8)return'Use at least 8 characters for the password.';if(state.admin_password!==state.admin_password2)return'The passwords do not match.';}
    return'';
  }
  async function chooseBadge(file){if(!file)return;const mime=String(file.type||'').toLowerCase(),name=String(file.name||'badge');if(!['image/png','image/jpeg','image/webp'].includes(mime)&&!/\.(png|jpe?g|webp)$/i.test(name)){message('Badge must be PNG, JPG or WebP.');return;}if(file.size>1048576){message('Badge must be 1 MB or smaller.');return;}const dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=()=>reject(new Error('Could not read that image.'));r.readAsDataURL(file);});state.badge={name,mime:mime||(/^.*\.webp$/i.test(name)?'image/webp':/\.png$/i.test(name)?'image/png':'image/jpeg'),dataUrl,base64:String(dataUrl).split(',')[1]||''};const p=document.getElementById('ob-badge-preview'),n=document.getElementById('ob-badge-name');if(p)p.innerHTML=`<img src="${dataUrl}" alt="Club badge preview"/>`;if(n)n.textContent=name;message('',false);}
  async function searchSelkent(){
    const q=document.getElementById('ob-selkent-query')?.value.trim()||'';
    if(q.length<2)return message('Type at least 2 letters of the club or team name.',true,'ob-provider-message');
    state.provider.config.club_search_query=q;
    const btn=document.getElementById('ob-selkent-search');if(btn){btn.disabled=true;btn.innerHTML='<span class="onboard-loading">Searching</span>';}
    try{
      const data=await edge('league-provider-discovery',{provider:'selkent',action:'search',query:q});
      clubResults=data.clubs||[];
      const box=document.getElementById('ob-club-results');
      if(box)box.innerHTML=clubResults.length?clubResults.map((c,i)=>`<div class="provider-result"><span><strong>${esc(c.name)}</strong></span><button type="button" data-selkent-result="${i}">Use club</button></div>`).join(''):'<div class="provider-summary">No matching club found in this league.</div>';
      bindProviderResults();
    }catch(e){message(e.message||String(e),true,'ob-provider-message');}
    finally{if(btn){btn.disabled=false;btn.textContent='Search teams';}}
  }
  function bindProviderResults(){
    document.querySelectorAll('[data-selkent-result]').forEach(b=>b.addEventListener('click',async()=>{
      const c=clubResults[Number(b.dataset.selkentResult)];if(!c)return;b.disabled=true;b.textContent='Loading…';
      try{
        const previousName=state.club_name;
        const previousConfig={...state.provider.config};
        const data=await edge('league-provider-discovery',{provider:'selkent',action:'inspect',club_id:c.id});
        state.club_name=c.name||state.club_name;if(!state.short_name||state.short_name===initials(previousName))state.short_name=initials(state.club_name);
        state.provider={type:'selkent',key:'selkent',label:data.league_name||previousConfig.league_name||'League',imported:true,config:{...previousConfig,club_name:state.club_name,club_search_query:previousConfig.club_search_query||'',club_url:data.source_url||c.url,directory_url:'https://www.selkent.org.uk/public/clubs/directory',divisions_url:'https://www.selkent.org.uk/public/divisions/all',fixtures_url:'https://www.selkent.org.uk/public/fixtures/all',results_url:'https://www.selkent.org.uk/public/results'}};
        state.teams=(data.teams||[]).map(t=>({...t,selected:true}));render();message(`${state.club_name} found. ${state.teams.length} team${state.teams.length===1?'':'s'} imported automatically.`,false,'ob-provider-message');
      }catch(e){message(e.message||String(e),true,'ob-provider-message');b.disabled=false;b.textContent='Use club';}
    }));
  }
  function dedupeCountyFAs(rows=[]){
    const map=new Map();
    rows.forEach(c=>{const name=String(c?.name||'').replace(/\s+/g,' ').trim();const key=nameKey(name);if(name&&key&&!map.has(key))map.set(key,{...c,name});});
    return [...map.values()].sort((a,b)=>a.name.localeCompare(b.name));
  }
  function renderLeagueDiscoveryResults(){
    const box=document.getElementById('ob-provider-results');if(box)box.innerHTML=leagueResultsHtml();bindLeagueDiscoveryResults();
  }
  async function loadCountyFAs(){
    const status=document.getElementById('ob-county-status');
    if(countyFaResults.length){if(status)status.textContent=`${countyFaResults.length} County FAs loaded from The FA.`;return;}
    try{
      const data=await edge('fa-league-discovery',{action:'counties'});
      countyFaResults=dedupeCountyFAs(Array.isArray(data.counties)?data.counties:[]);
      const selected=state.provider.config.county_fa_name||'';
      const select=document.getElementById('ob-county-fa');
      if(select)select.innerHTML=['<option value="">Choose County FA…</option>',...countyFaResults.map((c,i)=>`<option value="${i}" ${c.name===selected?'selected':''}>${esc(c.name)}</option>`)].join('');
      if(status)status.textContent=countyFaResults.length?`${countyFaResults.length} County FAs loaded from The FA.`:'The County FA directory could not be read. You can still use a Full-Time link below.';
      if(selected)await loadCountyLeagues();
    }catch(e){if(status)status.textContent='Could not load the County FA directory. You can still use a Full-Time link below.';}
  }
  async function loadCountyLeagues(){
    const countyName=state.provider.config.county_fa_name||'';
    if(!countyName)return;
    const status=document.getElementById('ob-league-status');
    if(status)status.textContent=`Reading the ${countyName} website for affiliated leagues…`;
    try{
      const data=await edge('fa-league-discovery',{action:'county_leagues',county_fa:countyName});
      providerResults=Array.isArray(data.leagues)?data.leagues:[];
      if(status)status.textContent=providerResults.length?`${providerResults.length} league${providerResults.length===1?'':'s'} found on the ${countyName} website. Select yours or filter the list.`:`No leagues could be read from the ${countyName} website. Try the filter or Full-Time link fallback below.`;
      renderLeagueDiscoveryResults();
    }catch(e){if(status)status.textContent='Could not read the County FA league directory. Try the Full-Time link fallback below.';message(e.message||String(e),true,'ob-provider-message');}
  }
  async function searchFullTimeLeagues(){
    const q=document.getElementById('ob-fulltime-query')?.value.trim()||'';
    const countyIndex=document.getElementById('ob-county-fa')?.value||'';
    if(countyIndex==='')return message('Choose your County FA first.',true,'ob-provider-message');
    const county=countyFaResults[Number(countyIndex)];
    if(county){state.provider.config.county_fa_name=county.name;state.provider.config.county_fa_website=county.website||'';state.provider.config.county_fa_source='https://www.thefa.com/about-football-association/who-we-are/county-fas';}
    if(!q){state.provider.config.league_search_query='';return loadCountyLeagues();}
    if(q.length<2)return message('Type at least 2 letters of the league name.',true,'ob-provider-message');
    state.provider.config.league_search_query=q;
    const btn=document.getElementById('ob-fulltime-search');if(btn){btn.disabled=true;btn.innerHTML='<span class="onboard-loading">Filtering</span>';}
    try{
      const data=await edge('fa-league-discovery',{action:'league_search',query:q,county_fa:county?.name||''});
      providerResults=Array.isArray(data.leagues)?data.leagues:[];
      const status=document.getElementById('ob-league-status');if(status)status.textContent=providerResults.length?`${providerResults.length} matching league${providerResults.length===1?'':'s'} found on the County FA website.`:'No matching league found on the County FA website. Try a shorter filter or the Full-Time link fallback.';
      renderLeagueDiscoveryResults();
      message('',false,'ob-provider-message');
    }catch(e){message(e.message||String(e),true,'ob-provider-message');}
    finally{if(btn){btn.disabled=false;btn.textContent='Filter';}}
  }
  function bindLeagueDiscoveryResults(){
    document.querySelectorAll('[data-league-result]').forEach(b=>b.addEventListener('click',async()=>{
      const r=providerResults[Number(b.dataset.leagueResult)];if(!r)return;b.disabled=true;b.textContent='Loading…';
      try{
        if(r.provider==='selkent'){
          const previous={...state.provider.config};
          state.provider={type:'selkent',key:'selkent',label:r.name||'League',imported:false,config:{...previous,league_url:r.url||'',league_name:r.name||'League',county_source_url:r.source_url||'',sync_mode:'selkent-public',league_loaded:true,club_search_query:state.club_name||''}};
          state.teams=[];leagueTeams=[];teamSearchResults=[];clubResults=[];render();
          message(`${state.provider.label} selected from the County FA directory. Search for your club or team to populate the setup.`,false,'ob-provider-message');
          return;
        }
        if(r.provider==='fulltime'&&r.url){await inspectFullTime(r.url,r.name);return;}
        const previous={...state.provider.config};
        state.provider={type:'external',key:'external',label:r.name||'League',imported:false,config:{...previous,league_url:r.url||'',league_name:r.name||'League',county_source_url:r.source_url||'',sync_mode:'external-public',league_loaded:true}};
        state.teams=[];leagueTeams=[];teamSearchResults=[];clubResults=[];render();
        message(`${state.provider.label} selected from the County FA website. This league uses its own site, so confirm your club name before continuing.`,false,'ob-provider-message');
      }catch(e){message(e.message||String(e),true,'ob-provider-message');b.disabled=false;b.textContent='Use league';}
    }));
  }
  function bindLeagueTeamResults(){document.querySelectorAll('[data-league-team-result]').forEach(b=>b.addEventListener('click',()=>selectLeagueTeam(Number(b.dataset.leagueTeamResult))));}
  function renderLeagueTeamResults(){const box=document.getElementById('ob-team-search-results');if(box)box.innerHTML=leagueTeamResultsHtml();bindLeagueTeamResults();}
  function searchLeagueTeams(){const input=document.getElementById('ob-league-team-query');const q=input?.value.trim()||'';if(q.length<2)return message('Type at least 2 letters of the club or team name.',true,'ob-provider-message');state.provider.config.team_search_query=q;teamSearchResults=filterLeagueTeams(q);renderLeagueTeamResults();message('',false,'ob-provider-message');}
  function selectLeagueTeam(index){
    const chosen=teamSearchResults[index];if(!chosen)return;
    const previousName=state.club_name;const club=inferClubName(chosen)||String(chosen.league_name||chosen.name||'').trim();const clubKey=nameKey(club);
    let related=leagueTeams.filter(t=>nameKey(inferClubName(t))===clubKey);if(!related.length)related=[chosen];
    const chosenKey=String(chosen.provider_team_id||'')||nameKey(chosen.league_name||chosen.name||'');
    state.club_name=club||state.club_name;if(!state.short_name||state.short_name===initials(previousName))state.short_name=initials(state.club_name);
    state.teams=related.map(t=>{const age=Number(t.age_group)||inferAgeText(t.league_name)||inferAgeText(t.provider_label)||null;const isChosen=(String(t.provider_team_id||'')||nameKey(t.league_name||t.name||''))===chosenKey;return{...t,name:teamShortName(t,state.club_name),club_name:state.club_name,age_group:age,provider_label:t.provider_label||t.league_name||t.name||'',league_name:t.league_name||t.name||'',selected:age?true:isChosen};});
    const allLinks=leagueTeams.map(t=>({provider_team_id:t.provider_team_id||'',name:t.league_name||t.name||'',age_group:Number(t.age_group)||inferAgeText(t.league_name)||null,division:t.division||'',source_url:t.source_url||''})).filter(t=>t.name&&t.source_url);
    const clubLinks=state.teams.map(t=>({provider_team_id:t.provider_team_id||'',name:t.league_name||t.name||'',age_group:Number(t.age_group)||null,division:t.division||'',source_url:t.source_url||''})).filter(t=>t.name&&t.source_url);
    state.provider.imported=true;state.provider.config={...state.provider.config,club_name:state.club_name,selected_team_id:chosen.provider_team_id||'',selected_team_name:chosen.league_name||chosen.name||'',selected_team_url:chosen.source_url||'',team_links:allLinks,club_team_links:clubLinks};
    render();message(`${state.club_name} selected. ${state.teams.length} matching team${state.teams.length===1?'':'s'} found in ${state.provider.label}.`,false,'ob-provider-message');
  }
  async function inspectFullTime(url,label=''){
    const data=await edge('league-provider-discovery',{provider:'fulltime',action:'inspect',url});
    const previous={...state.provider.config};
    leagueTeams=(data.teams||[]).map(normaliseLeagueTeam);
    const allLinks=leagueTeams.map(t=>({provider_team_id:t.provider_team_id||'',name:t.league_name||t.name||'',age_group:Number(t.age_group)||null,division:t.division||'',source_url:t.source_url||''})).filter(t=>t.name&&t.source_url);
    const teamQuery=String(previous.team_search_query||state.club_name||'').trim();
    state.provider={type:'fulltime',key:'fulltime',label:data.league_name||label||'FA Full-Time',imported:false,config:{...previous,league_url:data.source_url||url,league_name:data.league_name||label||'FA Full-Time',sync_mode:'fulltime-public',league_loaded:true,team_search_query:teamQuery,team_links:allLinks}};
    state.teams=[];teamSearchResults=filterLeagueTeams(teamQuery);render();
    const msg=leagueTeams.length?`${state.provider.label} loaded with ${leagueTeams.length} visible team record${leagueTeams.length===1?'':'s'}. Select your team to identify the club.`:'League loaded, but no team records were visible on this page. Try a division Full-Time link or Manual setup.';
    message(msg,!leagueTeams.length,'ob-provider-message');
  }
  async function readFullTime(){const url=document.getElementById('ob-fulltime-url')?.value.trim()||'';if(!url)return message('Paste the public FA Full-Time league or division URL.',true,'ob-provider-message');const btn=document.getElementById('ob-fulltime-read');if(btn){btn.disabled=true;btn.innerHTML='<span class="onboard-loading">Reading</span>';}try{await inspectFullTime(url);}catch(e){message(e.message||String(e),true,'ob-provider-message');}finally{if(btn&&document.body.contains(btn)){btn.disabled=false;btn.textContent='Use link';}}}
  function bind(){
    document.getElementById('onboard-close')?.addEventListener('click',close);
    document.getElementById('onboard-cancel')?.addEventListener('click',close);
    document.getElementById('onboard-back')?.addEventListener('click',()=>{saveStep();state.step=Math.max(1,state.step-1);render();});
    document.getElementById('onboard-next')?.addEventListener('click',async()=>{saveStep();const err=validate();if(err)return message(err);if(state.step<7){state.step++;render();return;}await createClub();});

    if(state.step===1){
      document.querySelectorAll('[data-setup-mode]').forEach(b=>b.addEventListener('click',()=>{
        const mode=b.dataset.setupMode;
        state.setup_mode=mode;
        providerResults=[];clubResults=[];leagueTeams=[];teamSearchResults=[];
        if(mode==='manual'){
          state.provider={type:'manual',key:'manual',label:'Manual setup',config:{},imported:true};
          state.teams=[];
        }else{
          state.provider={type:'fulltime',key:'fulltime',label:'League discovery',config:{},imported:false};
          state.teams=[];
        }
        render();
      }));
    }

    if(state.step===2&&state.setup_mode==='manual'){
      document.getElementById('ob-club-name')?.addEventListener('input',e=>{if(!document.getElementById('ob-short-name')?.value){document.getElementById('ob-short-name').value=initials(e.target.value);}});
    }

    if(state.step===2&&state.setup_mode==='auto'){
      document.getElementById('ob-selkent-search')?.addEventListener('click',searchSelkent);
      document.getElementById('ob-selkent-query')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchSelkent();}});
      document.getElementById('ob-fulltime-search')?.addEventListener('click',searchFullTimeLeagues);
      document.getElementById('ob-fulltime-read')?.addEventListener('click',readFullTime);
      document.getElementById('ob-league-team-search')?.addEventListener('click',searchLeagueTeams);
      document.getElementById('ob-league-team-query')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchLeagueTeams();}});
      document.getElementById('ob-fulltime-query')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchFullTimeLeagues();}});
      document.getElementById('ob-county-fa')?.addEventListener('change',async e=>{
        const value=e.target.value;
        if(value===''){
          state.provider={type:'fulltime',key:'fulltime',label:'League discovery',config:{},imported:false};
          providerResults=[];leagueTeams=[];teamSearchResults=[];clubResults=[];state.teams=[];render();return;
        }
        const c=countyFaResults[Number(value)];if(!c)return;
        state.provider={type:'fulltime',key:'fulltime',label:'League discovery',imported:false,config:{county_fa_name:c.name,county_fa_website:c.website||'',county_fa_source:'https://www.thefa.com/countyfa'}};
        providerResults=[];leagueTeams=[];teamSearchResults=[];clubResults=[];state.teams=[];
        render();
        await loadCountyLeagues();
      });
      bindProviderResults();bindLeagueDiscoveryResults();bindLeagueTeamResults();loadCountyFAs();
      document.getElementById('ob-club-name')?.addEventListener('input',e=>{if(!document.getElementById('ob-short-name')?.value){document.getElementById('ob-short-name').value=initials(e.target.value);}});
    }

    if(state.step===3){
      document.getElementById('ob-badge-picker')?.addEventListener('click',()=>document.getElementById('ob-badge')?.click());
      document.getElementById('ob-badge')?.addEventListener('change',e=>chooseBadge(e.target.files?.[0]).catch(()=>message('Could not read that image.')));
      ['ob-primary','ob-secondary','ob-accent'].forEach(id=>document.getElementById(id)?.addEventListener('input',()=>{const p=document.getElementById('ob-primary')?.value||state.primary_color,s=document.getElementById('ob-secondary')?.value||state.secondary_color,box=document.getElementById('ob-brand-live');if(box){box.style.setProperty('--preview-primary',p);box.style.setProperty('--preview-secondary',s);}}));
    }

    if(state.step===4){
      document.querySelectorAll('[data-team-index]').forEach(row=>{row.querySelector('.remove-team')?.addEventListener('click',()=>{state.teams.splice(Number(row.dataset.teamIndex),1);render();});});
      document.getElementById('ob-add-team')?.addEventListener('click',()=>{saveStep();const name=document.getElementById('ob-add-team-name')?.value.trim()||'',age=Number(document.getElementById('ob-add-team-age')?.value||0),division=document.getElementById('ob-add-team-division')?.value.trim()||'';if(!name)return message('Enter a team name.');state.teams.push({name,age_group:age,division,provider_label:`Under ${age}s ${name}`,league_name:`${state.club_name} ${name}`,selected:true});render();});
    }
  }
  async function handoffCreatedClub(){
    // Close onboarding immediately once the account exists. The previous build
    // kept the modal open while waiting for the cloud bootstrap, which made the
    // Create club button look stuck until another interaction forced a paint.
    close();
    await new Promise(resolve=>requestAnimationFrame(()=>resolve()));
    window.dispatchEvent(new CustomEvent('valiants-authenticated',{detail:{source:'club-onboarding'}}));
    const started=Date.now();
    while(Date.now()-started<4000){
      if(window.ValiantsCloud?.context?.profile)return true;
      await new Promise(resolve=>setTimeout(resolve,75));
    }
    // A hard replace is only a fallback. It runs without waiting for another tap.
    try{location.replace(location.pathname+location.search);}catch{location.reload();}
    return false;
  }
  function showCreatingClub(){
    if(!host)return;
    host.innerHTML=`<div class="onboard-shell creating-club-shell">${stepProgress()}<div class="onboard-main"><div class="onboard-heading"><p class="kicker">CREATE YOUR CLUB</p><h1>Creating your club</h1><p>Your Club Admin account and club workspace are being prepared.</p></div><div class="onboard-card creating-club-card"><div class="creating-club-spinner onboard-loading">Creating ${esc(state.club_name||'club')}…</div><p class="onboard-help">You will be taken straight to the Club Admin dashboard when this completes. No second tap is required.</p></div></div></div>`;
  }
  async function createClub(){
    const btn=document.getElementById('onboard-next');
    if(btn){btn.disabled=true;btn.innerHTML='<span class="onboard-loading">Creating club</span>';}
    showCreatingClub();
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    try{
      syncRules();const rules=Object.values(state.rules);const results=rules.filter(r=>r.results_published).map(r=>r.age_group).sort((a,b)=>a-b);const playerAges=rules.filter(r=>r.player_accounts_allowed).map(r=>r.age_group);
      const payload={club_name:state.club_name,short_name:state.short_name,slug:slugify(state.club_name),season:state.season,country_code:state.country_code,timezone:state.timezone,primary_color:state.primary_color,secondary_color:state.secondary_color,accent_color:state.accent_color,provider:{type:state.provider.type,key:state.provider.key,config:state.provider.config},teams:selectedTeams().map(t=>({name:t.name,age_group:Number(t.age_group),division:t.division||'',provider_label:t.provider_label||`Under ${t.age_group}s ${t.name}`,league_name:t.league_name||`${state.club_name} ${t.name}`})),rules,results_publish_from_age:results.length?results[0]:null,player_account_age_groups:playerAges,admin_name:state.admin_name,admin_email:state.admin_email,admin_password:state.admin_password};
      const data=await edge('club-onboarding',{payload,badge:state.badge?{base64:state.badge.base64,mime:state.badge.mime,name:state.badge.name}:null});
      if(!data?.session)throw new Error('Club was created but no sign-in session was returned.');
      const session={...data.session};if(!session.expires_at&&session.expires_in)session.expires_at=Math.floor(Date.now()/1000)+Number(session.expires_in);
      localStorage.setItem(SESSION_KEY,JSON.stringify(session));localStorage.removeItem('grassroots_hub_debug_test_mode_v1');localStorage.removeItem('grassroots_hub_debug_club_v1');
      await handoffCreatedClub();
    }catch(e){
      render();
      await new Promise(resolve=>requestAnimationFrame(resolve));
      message(e.message||String(e));
    }
  }
    function open(){if(!host){host=document.createElement('section');host.id='universal-onboarding';host.className='universal-onboarding';document.body.appendChild(host);}host.classList.remove('hidden');document.body.style.overflow='hidden';state.step=1;render();}
  function close(){if(host)host.classList.add('hidden');document.body.style.overflow='';}
  window.UniversalOnboarding={open,close};
})();
