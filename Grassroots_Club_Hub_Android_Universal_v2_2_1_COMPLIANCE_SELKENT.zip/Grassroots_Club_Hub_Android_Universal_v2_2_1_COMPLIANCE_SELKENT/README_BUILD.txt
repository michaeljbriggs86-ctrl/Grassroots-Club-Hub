Grassroots Club Hub Android Universal v2.2.1

Application ID
  com.grassrootsclubhub.universal

Version
  2.2.1 (versionCode 2201)

Build
  This source includes a GitHub Actions workflow. Locally, with Android SDK and Gradle installed:
    gradle :app:assembleDebug

Current product scope
- Native Android WebView shell with bundled HTML/JavaScript application assets.
- Automatic competition data is deliberately limited to Selkent (selkent.org.uk).
- Automatic onboarding searches only the stored Selkent club/team directory.
- Manual setup remains available when a club chooses not to use an external competition feed.
- FA Full-Time / Find Football acquisition is disabled for this release.

Onboarding order
  1. Setup method
  2. Find/select Selkent club or enter manually
  3. Branding
  4. Teams
  5. Football rules
  6. Club Admin
  7. Safeguarding & dispute roles
  8. Review / Create club

Compliance / privacy enforcement
- U7-U11 score/result/W-D-L/GF-GA/GD/win-rate/table data is removed server-side for parent/player responses.
- U7-U11 goals, assists and awards are persisted by shirt number; the per-season name-to-shirt mapping is private server data.
- U7-U11 parent-player links do not store shirt numbers.
- U7-U11 general exports are disabled. The only export is a separate audited safeguarding pack containing emergency-contact and medical/allergy data.
- Inbox is Club Admin / Coach / Assistant Coach / Parent only. Active messages expire per message after 60 days; retained dispute copies are reviewer-only.
- Safeguarding concern content is never stored in-app; the app logs routing metadata only and directs the reporter externally.
- Player departures are queued for end-of-season identifying/squad/match-involvement deletion.
- Club cancellation creates a 30-day database deletion deadline.
- New-club onboarding requires dispute-review and safeguarding contacts.
- Public results publication has a database-enforced floor of U12.

Important live-backend note
- The production Supabase project contains the current enforcement functions/tables/jobs. Older SQL/Edge files retained in this source archive are historical reference only and should not be redeployed over the live backend.
