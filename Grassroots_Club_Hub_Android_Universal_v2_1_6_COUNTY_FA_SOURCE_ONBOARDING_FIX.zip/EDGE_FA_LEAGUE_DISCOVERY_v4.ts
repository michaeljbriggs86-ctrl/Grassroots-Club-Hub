import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import * as XLSX from "npm:xlsx@0.18.5";

const cors={
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods":"GET, POST, OPTIONS",
  "Content-Type":"application/json; charset=utf-8"
};
const reply=(v:unknown,s=200)=>new Response(JSON.stringify(v),{status:s,headers:cors});
const decode=(s:string)=>String(s||'').replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&#39;|&#x27;/gi,"'").replace(/&quot;/gi,'"').replace(/&ndash;|&mdash;/gi,'-');
const clean=(s:string)=>decode(String(s||'').replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<[^>]+>/g," ")).replace(/\s+/g," ").trim();
const norm=(s:string)=>clean(s).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,' ').trim();
const FA_URL='https://www.thefa.com/countyfa';

const KNOWN_COUNTIES=[
  'AMATEUR FOOTBALL ALLIANCE','ARMY FA','BEDFORDSHIRE FA','BERKS & BUCKS FA','BIRMINGHAM FA','CAMBRIDGESHIRE FA','CHESHIRE FA','CORNWALL FA','CUMBERLAND FA','DERBYSHIRE FA','DEVON FA','DORSET FA','DURHAM FA','EAST RIDING FA','ESSEX FA','GLOUCESTERSHIRE FA','GUERNSEY FA','HAMPSHIRE FA','HEREFORDSHIRE FA','HERTFORDSHIRE FA','HUNTINGDONSHIRE FA','ISLE OF MAN FA','JERSEY FA','KENT FA','LANCASHIRE FA','LEICESTERSHIRE & RUTLAND FA','LINCOLNSHIRE FA','LIVERPOOL FA','LONDON FA','MANCHESTER FA','MIDDLESEX FA','NORFOLK FA','NORTHAMPTONSHIRE FA','NORTH RIDING FA','NORTHUMBERLAND FA','NOTTINGHAMSHIRE FA','OXFORDSHIRE FA','RAF FA','ROYAL NAVY FA','SHEFFIELD & HALLAMSHIRE FA','SHROPSHIRE FA','SOMERSET FA','STAFFORDSHIRE FA','SUFFOLK FA','SURREY FA','SUSSEX FA','WESTMORLAND FA','WEST RIDING FA','WILTSHIRE FA','WORCESTERSHIRE FA'
];
const KNOWN_BY_KEY=new Map(KNOWN_COUNTIES.map(n=>[norm(n),n]));

const UA='Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36 GrassrootsClubHub/2.1.6';
async function fetchAny(url:string){
  const r=await fetch(url,{headers:{"User-Agent":UA,"Accept":"text/html,application/xhtml+xml,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv,*/*"},redirect:'follow'});
  if(!r.ok)throw new Error(`Source returned HTTP ${r.status}`);
  return r;
}
async function getHtml(url:string){const r=await fetchAny(url);return{html:await r.text(),url:r.url,contentType:r.headers.get('content-type')||''};}

function htmlLines(html:string){
  return decode(html
    .replace(/<script[\s\S]*?<\/script>/gi,' ')
    .replace(/<style[\s\S]*?<\/style>/gi,' ')
    .replace(/<br\s*\/?>/gi,'\n')
    .replace(/<\/(?:p|div|li|h1|h2|h3|h4|h5|h6|tr|td|th|section|article|option)>/gi,'\n')
    .replace(/<[^>]+>/g,' '))
    .split(/\n+/).map(x=>x.replace(/\s+/g,' ').trim()).filter(Boolean);
}
function anchorRows(html:string,base:string){
  const out:any[]=[];
  for(const m of html.matchAll(/<a\b[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi)){
    let url='';try{url=new URL(decode(m[1]),base).toString();}catch{continue;}
    const text=clean(m[2]);if(!text)continue;
    out.push({text,url,index:m.index||0,raw:m[0]});
  }
  return out;
}
function contextName(context:string){
  const tags=[...context.matchAll(/<(?:h2|h3|h4|h5|strong)\b[^>]*>([\s\S]*?)<\/(?:h2|h3|h4|h5|strong)>/gi)].map(m=>clean(m[1])).filter(Boolean);
  const usable=tags.filter(n=>n.length>2&&n.length<110&&!/^(website|email|phone|tel|address|contact|chairperson|chief executive|ceo|county fas?)(?:\s*:|$)/i.test(n));
  for(let i=usable.length-1;i>=0;i--){if(/\b(?:FA|FOOTBALL|ASSOCIATION)\b/i.test(usable[i]))return usable[i];}
  return usable.at(-1)||'';
}
function canonicalCountyName(name:string){
  const raw=clean(name).toUpperCase();
  if(!raw)return'';
  for(const known of KNOWN_COUNTIES){if(norm(raw).includes(norm(known)))return known;}
  return KNOWN_BY_KEY.get(norm(raw))||raw;
}
function parseCounties(html:string,base:string){
  const websiteByName=new Map<string,any>();
  const anchors=anchorRows(html,base);
  for(const a of anchors){
    let u:URL;try{u=new URL(a.url);}catch{continue;}
    const host=u.hostname.toLowerCase().replace(/^www\./,'');
    if(/(?:thefa\.com|englandfootball\.com|wembleystadium\.com|facebook\.com|instagram\.com|youtube\.com|tiktok\.com|twitter\.com|x\.com)$/.test(host))continue;
    const ctx=html.slice(Math.max(0,a.index-2200),a.index);
    const raw=canonicalCountyName(contextName(ctx));
    let official=KNOWN_BY_KEY.get(norm(raw));
    if(!official){
      const ctxKey=norm(clean(ctx));
      official=KNOWN_COUNTIES.find(n=>ctxKey.includes(norm(n)));
    }
    if(!official)continue;
    const key=norm(official);
    const candidate={name:official,website:u.origin+(u.pathname==='/'?'':u.pathname.replace(/\/$/,'')),host};
    if(!websiteByName.has(key))websiteByName.set(key,candidate);
  }
  return KNOWN_COUNTIES.map(name=>websiteByName.get(norm(name))||{name,website:'',host:''});
}

function classifyProvider(name:string,url:string){
  const n=norm(name),u=String(url||'').toLowerCase();
  if(n.includes('selkent')||u.includes('selkent.org.uk'))return'selkent';
  if(/(?:full-?time|fulltime)(?:-league)?\.thefa\.com/i.test(u))return'fulltime';
  return'external';
}
function leagueLikeName(value:string){
  const v=clean(value),n=norm(v);
  if(!v||v.length<4||v.length>150)return false;
  if(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/i.test(v)||/\b(?:0\d{2,4}|07\d{3})\s*\d+/i.test(v))return false;
  if(/^(?:county leagues?|affiliated leagues?|leagues?(?:\s*&\s*clubs)?|youth leagues?|girls'? leagues?|women'?s? leagues?|adult.*leagues?|open age.*leagues?|inclusive leagues?|disability leagues?|walking football|veteran'?s? football leagues?|alternative formats.*|league tables?|league website|website|click here.*|find a league.*|other football leagues.*)$/i.test(v))return false;
  if(/^(?:secretary|chair|chairman|chairperson|contact|phone|tel|email|saturday|sunday|mid-?week)\b/i.test(v))return false;
  return /\bleague\b/i.test(v) || /\bfootball\s+(?:combination|alliance|partnership)\b/i.test(v);
}
function normaliseLeagueName(value:string){return clean(value).replace(/\s*[-–—]\s*(?:Secretary|Chair(?:man|person)?|Contact).*$/i,'').trim();}
function leagueKey(name:string,url:string){return `${norm(name)}|${String(url||'').replace(/\/$/,'').toLowerCase()}`;}
function dedupeLeagues(rows:any[]){
  const byName=new Map<string,any>();
  for(const raw of rows){
    const name=normaliseLeagueName(raw?.name||'');if(!leagueLikeName(name))continue;
    const url=String(raw?.url||'').trim();const key=norm(name);
    const row={id:String(raw?.id||key),name,url,provider:raw?.provider||classifyProvider(name,url),source:raw?.source||'County FA website',source_url:String(raw?.source_url||''),category:String(raw?.category||'')};
    const current=byName.get(key);
    if(!current || (!current.url&&row.url) || (current.provider==='external'&&row.provider!=='external'))byName.set(key,row);
  }
  return [...byName.values()].sort((a,b)=>a.name.localeCompare(b.name));
}

function parseLeaguePage(html:string,pageUrl:string){
  const rows:any[]=[];const anchors=anchorRows(html,pageUrl);
  const pageHost=new URL(pageUrl).hostname.replace(/^www\./,'');
  for(const a of anchors){
    let host='';try{host=new URL(a.url).hostname.replace(/^www\./,'');}catch{}
    if(leagueLikeName(a.text)){
      rows.push({name:a.text,url:a.url,provider:classifyProvider(a.text,a.url),source:'County FA website',source_url:pageUrl});
      continue;
    }
    if(/^(?:league tables?|league website|website|click here.*(?:league|website))/i.test(a.text)){
      const before=html.slice(Math.max(0,a.index-900),a.index);
      const candidates=htmlLines(before).filter(leagueLikeName);
      const name=candidates.at(-1)||'';
      if(name)rows.push({name,url:a.url,provider:classifyProvider(name,a.url),source:'County FA website',source_url:pageUrl});
    }
    // Avoid turning unrelated external sponsor links into leagues.
    if(host&&host!==pageHost&&/\bleague\b/i.test(a.text))rows.push({name:a.text,url:a.url,provider:classifyProvider(a.text,a.url),source:'County FA website',source_url:pageUrl});
  }
  for(const line of htmlLines(html)){if(leagueLikeName(line))rows.push({name:line,url:'',provider:classifyProvider(line,''),source:'County FA website',source_url:pageUrl});}
  return dedupeLeagues(rows);
}

function candidateListLinks(html:string,base:string){
  const out:any[]=[];const baseHost=new URL(base).hostname.replace(/^www\./,'');
  for(const a of anchorRows(html,base)){
    let host='';try{host=new URL(a.url).hostname.replace(/^www\./,'');}catch{}
    const t=norm(a.text),u=a.url.toLowerCase();
    const internal=host===baseHost;
    const isPage=internal && (/(?:league|leagues-and-clubs|clubs-and-leagues)/i.test(u)||/(?:county|affiliated) leagues|leagues & clubs|leagues and clubs/i.test(a.text));
    const isDownload=/(?:\.xlsx?|\.csv)(?:$|\?)/i.test(u)||(/\.ashx(?:$|\?)/i.test(u)&&/league|download|list/i.test(a.text));
    if(isPage||isDownload)out.push({...a,type:isDownload?'download':'page'});
  }
  const seen=new Set<string>();return out.filter(x=>{const k=x.url.toLowerCase();if(seen.has(k))return false;seen.add(k);return true;});
}

async function parseSpreadsheet(url:string,sourcePage:string){
  const r=await fetchAny(url);const buf=await r.arrayBuffer();
  const wb=XLSX.read(new Uint8Array(buf),{type:'array',cellHTML:false,cellText:true});
  const rows:any[]=[];
  for(const sheetName of wb.SheetNames){
    const ws=wb.Sheets[sheetName];const range=XLSX.utils.decode_range(ws['!ref']||'A1:A1');
    for(let rr=range.s.r;rr<=range.e.r;rr++){
      const cells:any[]=[];
      for(let cc=range.s.c;cc<=range.e.c;cc++){
        const addr=XLSX.utils.encode_cell({r:rr,c:cc});const cell:any=ws[addr];if(!cell)continue;
        const value=clean(String(cell.w??cell.v??''));if(!value)continue;
        cells.push({value,url:String(cell.l?.Target||'')});
      }
      const names=cells.map(c=>c.value).filter(leagueLikeName);if(!names.length)continue;
      const name=names[0];
      const direct=cells.find(c=>c.url)?.url||cells.map(c=>c.value).find(v=>/^https?:\/\//i.test(v))||cells.map(c=>c.value).find(v=>/^www\./i.test(v))||'';
      let resolved='';if(direct){try{resolved=new URL(/^www\./i.test(direct)?`https://${direct}`:direct,url).toString();}catch{}}
      rows.push({name,url:resolved,provider:classifyProvider(name,resolved),source:'County FA league list',source_url:sourcePage});
    }
  }
  return dedupeLeagues(rows);
}

async function getCountyDirectory(){const page=await getHtml(FA_URL);return parseCounties(page.html,page.url);}
async function resolveCounty(countyFa:string){
  const counties=await getCountyDirectory();const key=norm(countyFa);const found=counties.find(c=>norm(c.name)===key);
  if(!found)throw new Error('County FA not found in The FA directory');
  if(!found.website)throw new Error(`${found.name} website was not available from The FA directory`);
  return found;
}

async function countyLeagues(countyFa:string){
  const county=await resolveCounty(countyFa);const root=county.website.replace(/\/$/,'');
  const pageUrls=[root,`${root}/leagues-and-clubs`,`${root}/leagues-and-clubs/county-leagues`,`${root}/leagues-and-clubs/affiliated-leagues`,`${root}/leagues-and-clubs/leagues`,`${root}/clubs-and-leagues`,`${root}/clubs-and-leagues/leagues`];
  const seenPages=new Set<string>();const leagueRows:any[]=[];const downloads:any[]=[];const sources:string[]=[];
  for(const url of pageUrls){
    if(seenPages.has(url))continue;seenPages.add(url);
    try{
      const page=await getHtml(url);sources.push(page.url);leagueRows.push(...parseLeaguePage(page.html,page.url));
      for(const link of candidateListLinks(page.html,page.url)){
        if(link.type==='download')downloads.push({url:link.url,sourcePage:page.url});
        else if(!seenPages.has(link.url)&&seenPages.size<15){
          try{const sub=await getHtml(link.url);seenPages.add(link.url);sources.push(sub.url);leagueRows.push(...parseLeaguePage(sub.html,sub.url));for(const dl of candidateListLinks(sub.html,sub.url).filter(x=>x.type==='download'))downloads.push({url:dl.url,sourcePage:sub.url});}catch{}
        }
      }
    }catch{}
  }
  const downloadSeen=new Set<string>();
  for(const dl of downloads){
    if(downloadSeen.has(dl.url))continue;downloadSeen.add(dl.url);
    try{leagueRows.push(...await parseSpreadsheet(dl.url,dl.sourcePage));}catch{}
  }
  return {county,leagues:dedupeLeagues(leagueRows).slice(0,120),sources:[...new Set(sources)].slice(0,20)};
}

async function searchCountyLeagues(query:string,countyFa:string){
  const data=await countyLeagues(countyFa);const q=norm(query);if(!q)return data;
  const terms=q.split(/\s+/).filter(Boolean);
  const leagues=data.leagues.map((r:any)=>{const n=norm(r.name);let score=n.includes(q)?100:0;for(const t of terms)if(n.includes(t))score+=20;return{...r,_score:score};}).filter((r:any)=>r._score>0).sort((a:any,b:any)=>b._score-a._score||a.name.localeCompare(b.name)).map(({_score,...r}:any)=>r);
  return {...data,leagues};
}

async function handle(action:string,b:any){
  if(action==='counties'){const page=await getHtml(FA_URL);return{source_url:page.url,counties:parseCounties(page.html,page.url)};}
  if(action==='county_leagues'){
    const county=String(b?.county_fa||'').trim();if(!county)throw new Error('Choose a County FA first');
    const data=await countyLeagues(county);return{county_fa:data.county.name,county_website:data.county.website,source:'County FA website',sources:data.sources,leagues:data.leagues};
  }
  if(action==='league_search'){
    const county=String(b?.county_fa||'').trim();if(!county)throw new Error('Choose a County FA first');
    const data=await searchCountyLeagues(String(b?.query||''),county);return{county_fa:data.county.name,county_website:data.county.website,source:'County FA website',sources:data.sources,leagues:data.leagues};
  }
  throw new Error('Unsupported action');
}

Deno.serve(async(req:Request)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  try{
    if(req.method==='GET'){
      const u=new URL(req.url);const action=u.searchParams.get('action')||'';
      return reply(await handle(action,{county_fa:u.searchParams.get('county_fa')||'',query:u.searchParams.get('query')||''}));
    }
    if(req.method!=='POST')return reply({error:'Method not allowed'},405);
    const b=await req.json();return reply(await handle(String(b?.action||''),b));
  }catch(e){return reply({error:e instanceof Error?e.message:String(e)},502);}
});
