# Design reference folder

The **canonical current UI authority** is `APP-UI-DESIGN-GUIDELINES.md` in the shared Google Drive `00 - CURRENT MASTER` folder.

This source archive contains a dated, byte-for-byte content snapshot named `APP-UI-DESIGN-GUIDELINES-SNAPSHOT-2026-09-19.md` for build provenance. If the snapshot and the Drive canonical file ever differ, stop and reconcile the conflict before implementing UI changes.

Visual references in this folder support the text standard; they do not override it.
