package com.shootershill.valiants;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CalendarContract;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private int topInset = 0, bottomInset = 0;
    private boolean pageReady = false;
    private String pendingAuthUri = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36 ShootersHillTracker/2.0.22");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new NativeBridge(), "ValiantsNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme();
                if ("shootershilltracker".equalsIgnoreCase(scheme)) {
                    queueAuthCallback(u.toString());
                    return true;
                }
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    v.loadUrl(u.toString());
                    return true;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                if (url != null && url.startsWith("file:///android_asset/index.html")) {
                    pageReady = true;
                    applySystemInsetToPage();
                    dispatchPendingAuthCallback(0);
                }
            }
        });

        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets t = insets.getInsets(WindowInsets.Type.statusBars());
                Insets b = insets.getInsets(WindowInsets.Type.navigationBars());
                topInset = t.top;
                bottomInset = b.bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            applySystemInsetToPage();
            return insets;
        });

        handleIntent(getIntent());
        webView.loadUrl("file:///android_asset/index.html?build=cloud");
        webView.requestApplyInsets();
    }

    private void applySystemInsetToPage() {
        if (webView == null || !pageReady) return;
        webView.evaluateJavascript(
            "document.documentElement.style.setProperty('--android-inset-top','" + topInset + "px');" +
            "document.documentElement.style.setProperty('--android-inset-bottom','" + bottomInset + "px');" +
            "window.dispatchEvent(new CustomEvent('android-inset-change',{detail:{top:" + topInset + ",bottom:" + bottomInset + "}}));",
            null
        );
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri data = intent.getData();
        if (!"shootershilltracker".equalsIgnoreCase(data.getScheme())) return;
        queueAuthCallback(data.toString());
    }

    private void queueAuthCallback(String uri) {
        pendingAuthUri = uri;
        dispatchPendingAuthCallback(0);
    }

    private void dispatchPendingAuthCallback(int attempt) {
        if (!pageReady || webView == null || pendingAuthUri == null) return;
        final String uri = pendingAuthUri;
        final String js = "(function(){" +
            "if(window.ValiantsCloud&&window.ValiantsCloud.handleAuthCallback){" +
            "Promise.resolve(window.ValiantsCloud.handleAuthCallback(" + JSONObject.quote(uri) + ")).catch(function(){});" +
            "return 'delivered';}" +
            "return 'wait';" +
            "})()";
        webView.evaluateJavascript(js, value -> {
            if (value != null && value.contains("delivered")) {
                if (uri.equals(pendingAuthUri)) pendingAuthUri = null;
                return;
            }
            if (attempt < 40) mainHandler.postDelayed(() -> dispatchPendingAuthCallback(attempt + 1), 100);
        });
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript(";(window.closeTopDialog && window.closeTopDialog()) === true", v -> {
            if ("true".equals(v)) return;
            if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
        });
    }

    final class NativeBridge {
        private final Handler main = new Handler(Looper.getMainLooper());

        @JavascriptInterface public void request(String requestId, String url, String method, String body) {
            new Thread(() -> doRequest(requestId, url, method, body)).start();
        }

        private void doRequest(String requestId, String url, String method, String body) {
            int status = 0; String text = "", error = ""; HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                String m = (method == null || method.isEmpty() ? "GET" : method.toUpperCase());
                c.setRequestMethod(m);
                c.setRequestProperty("User-Agent", webView.getSettings().getUserAgentString());
                c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null && !cookies.isEmpty()) c.setRequestProperty("Cookie", cookies);
                if (!"GET".equals(m) && body != null && !body.isEmpty()) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                }
                status = c.getResponseCode();
                Map<String, List<String>> headers = c.getHeaderFields();
                List<String> setCookies = headers.get("Set-Cookie");
                if (setCookies != null) for (String ck : setCookies) CookieManager.getInstance().setCookie(url, ck);
                InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                text = read(in);
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            } finally {
                if (c != null) c.disconnect();
            }
            final int st = status; final String tx = text, er = error;
            main.post(() -> webView.evaluateJavascript("window.__nativeFetchResolve(" + JSONObject.quote(requestId) + "," + st + "," + JSONObject.quote(tx) + "," + JSONObject.quote(er) + ")", null));
        }

        private String read(InputStream in) throws Exception {
            if (in == null) return "";
            StringBuilder b = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line; while ((line = r.readLine()) != null) b.append(line).append('\n');
            }
            return b.toString();
        }

        @JavascriptInterface public void renderPage(String requestId, String url, String choicesJson) {
            main.post(() -> startRenderer(requestId, url, choicesJson));
        }

        private void startRenderer(String requestId, String url, String choicesJson) {
            final WebView renderer = new WebView(MainActivity.this);
            WebSettings s = renderer.getSettings();
            s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setUserAgentString(webView.getSettings().getUserAgentString());
            CookieManager.getInstance().setAcceptThirdPartyCookies(renderer, true);
            final JSONArray choices;
            try { choices = new JSONArray(choicesJson == null ? "[]" : choicesJson); }
            catch (Exception e) { resolveRendered(requestId, 0, "", e.getMessage(), url); renderer.destroy(); return; }
            final int[] idx = {0}; final String[] lastUrl = {url}; final Handler h = new Handler(Looper.getMainLooper());
            renderer.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String pageUrl) { lastUrl[0] = pageUrl; h.postDelayed(this::advance, 650); }
                private void advance() {
                    if (idx[0] >= choices.length()) {
                        renderer.evaluateJavascript("(function(){return document.documentElement?document.documentElement.outerHTML:'';})()", value -> {
                            String html = unquote(value); resolveRendered(requestId, 200, html, "", lastUrl[0]); renderer.destroy();
                        });
                        return;
                    }
                    String choice = choices.optString(idx[0]++, "");
                    String script = "(function(choice){const n=s=>String(s||'').toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,' ').trim().replace(/\\s+/g,' ');const target=n(choice);const els=[...document.querySelectorAll('a,button,summary,[role=tab],[role=button],label,option')];let el=els.find(x=>n(x.textContent||x.value)===target)||els.find(x=>target.length>2&&n(x.textContent||x.value).includes(target));if(!el)return 'missing';if(el.tagName==='OPTION'){const sel=el.parentElement;sel.value=el.value;el.selected=true;sel.dispatchEvent(new Event('change',{bubbles:true}));sel.dispatchEvent(new Event('input',{bubbles:true}));return 'changed';}el.scrollIntoView({block:'center'});el.click();return 'clicked';})(" + JSONObject.quote(choice) + ")";
                    renderer.evaluateJavascript(script, value -> h.postDelayed(this::advance, 900));
                }
            });
            renderer.loadUrl(url);
        }

        private String unquote(String value) {
            if (value == null || "null".equals(value)) return "";
            try { return new JSONArray("[" + value + "]").getString(0); } catch (Exception e) { return value; }
        }

        private void resolveRendered(String id, int status, String html, String error, String finalUrl) {
            webView.evaluateJavascript("window.__nativeRenderResolve(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(html) + "," + JSONObject.quote(error == null ? "" : error) + "," + JSONObject.quote(finalUrl == null ? "" : finalUrl) + ")", null);
        }

        @JavascriptInterface public boolean isDebugBuild() { return (getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0; }

        @JavascriptInterface public void addCalendarEvent(String title, String description, String location, String startIso, String endIso) {
            main.post(() -> {
                try {
                    java.time.ZonedDateTime start = java.time.ZonedDateTime.parse(startIso);
                    java.time.ZonedDateTime end = java.time.ZonedDateTime.parse(endIso);
                    Intent intent = new Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, title == null ? "Shooters Hill fixture" : title)
                        .putExtra(CalendarContract.Events.DESCRIPTION, description == null ? "" : description)
                        .putExtra(CalendarContract.Events.EVENT_LOCATION, location == null ? "" : location)
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.toInstant().toEpochMilli())
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end.toInstant().toEpochMilli());
                    startActivity(intent);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public String signAssignment(String payloadB64) { return ""; }
        @JavascriptInterface public boolean verifyAssignment(String payloadB64, String signature) { return false; }
    }
}
