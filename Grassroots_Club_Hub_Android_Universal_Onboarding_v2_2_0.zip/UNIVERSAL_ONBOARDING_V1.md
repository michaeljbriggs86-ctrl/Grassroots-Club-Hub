# Grassroots Club Hub — Universal Onboarding v1

Version 2.2.0 adds self-service multi-club onboarding on top of Universal Core v1.

## New club setup
A new club can now complete: Club details → Branding → Competition provider → Teams → Football rules → First Club Admin → Review/Create → Coach invites.

## Provider options
- Manual: fixtures/results entered manually.
- Selkent: club lookup matches the Selkent directory and imports the published team list.

## Tenant provisioning
The onboarding Edge Function creates the Auth user, isolated club tenant, club settings, provider, teams, age rules and first Club Admin. Failed provisioning deletes the temporary Auth user.

## Platform demo mode
Debug builds can mark a newly created club as a removable demo tenant. A demo Club Admin can remove that tenant from More → Club configuration. Shooters Hill and other non-demo tenants cannot be deleted through this control.

## Setup checklist
Club Admin configuration shows team setup, provider connection, coaching coverage and squad-start progress.

## Current beta note
Self-service onboarding is a beta flow. Billing/subscription enforcement and abuse/rate controls are intentionally the next commercialisation layer rather than being coupled to tenant creation now.
