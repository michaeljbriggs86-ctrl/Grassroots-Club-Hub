Grassroots Club Hub Android Universal v2.2.4 — Mock-up Exact Login UI Source

Protocol status check: 2026-09-19
Canonical status vocabulary: PLANNED / WRITTEN / TESTED / BUILT / DEPLOYED-LIVE
Canonical architecture: ARCHITECTURE.md in 00 - CURRENT MASTER
Collaboration rules: AI-COLLABORATION-PROTOCOL.md in 00 - CURRENT MASTER

Application ID
  com.grassrootsclubhub.universal

Version
  2.2.4 (versionCode 2204)

Current v2.2.4 status — checked 2026-09-19
  WRITTEN
    - Login UI/auth flow source has been updated.
    - The approved login mock-up is the UI acceptance target, not merely a theme reference.
    - Adult email/password, separate Player Access, and Club Sign Up entry screens
      are implemented in the bundled WebView source.
    - Existing v2.2.2 static directory/standings integration remains present.

  TESTED
    - cloud.js, onboarding.js and app.js pass Node JavaScript syntax checks.
    - Expected v2.2.4 version marker and static-feed-overlay reference were checked
      directly in this source tree.
    - Player-access Edge Function source parses through TypeScript until expected
      Deno/remote-module environment resolution errors; it has NOT been executed
      against a Supabase runtime.

  BUILT
    - NOT VERIFIED for v2.2.4. No v2.2.4 APK has been produced and inspected in
      this environment.

  DEPLOYED-LIVE
    - NOT VERIFIED / NOT CLAIMED.

Authentication changes
  Adults
    - Club Admins, Coaches and Parents use the same opening email/password page.
    - Role/profile after authentication determines the account they enter.
    - First-time adult invite setup remains as a transitional provisioning path,
      but subsequent access uses email/password.

  Players
    - New design uses Player Name + reusable Player Code and asks for no player
      email address or phone number.
    - Current product rule remains U15-only; this source does not expand player
      accounts to younger age groups.
    - The new server component is under pending_backend_not_deployed/ and is
      WRITTEN only. It is not part of the verified live backend yet.

  Clubs
    - The opening page now has a dedicated Club Sign Up route.
    - Club name, adult admin email/password and provider choice prefill the
      existing club onboarding flow.
    - Automatic provider scope remains Selkent; manual setup remains available.

Visual design
  The approved mock-up is followed as the active login theme:
    - white/green presentation;
    - shield + football Grassroots Club Hub branding;
    - football-scene hero imagery;
    - rounded outlined input fields;
    - full-width green primary actions;
    - outlined Player Login secondary action;
    - grass/football footer treatment;
    - matching Adult Login / Player Login / Club Sign Up screen family.

Build
  GitHub Actions workflow in this source package:
    .github/workflows/android.yml

  Local build, with Android SDK and Gradle installed:
    gradle :app:assembleDebug

  IMPORTANT: running a workflow is not by itself proof of BUILT status. Inspect
  the resulting APK and record its hash/content before using BUILT, and inspect
  the actually distributed/installed APK before using DEPLOYED-LIVE.

Backend status
  Existing backend contract:
    DEPLOYED-LIVE — last verified 2026-09-18 by the live backend export.

  New reusable Player Access backend:
    WRITTEN — NOT DEPLOYED.
    See pending_backend_not_deployed/README.md.

Historical evidence
  BUILD-VERIFICATION-v2.2.2.md and RELEASE_NOTES_v2_2_2.txt remain historical
  evidence for the previously inspected v2.2.2 APK. They are not v2.2.4 proof.


UI STANDARD (v2.2.5): Before UI work, read canonical Drive file APP-UI-DESIGN-GUIDELINES.md. A dated snapshot is bundled under design_reference/. No deviations without explicit Mike approval.
