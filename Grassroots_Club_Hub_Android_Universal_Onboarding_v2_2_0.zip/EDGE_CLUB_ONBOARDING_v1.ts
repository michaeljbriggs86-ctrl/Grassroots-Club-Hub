import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL=Deno.env.get("SUPABASE_URL")??"";
const SERVICE_ROLE=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")??"";
const ANON_KEY=Deno.env.get("SUPABASE_ANON_KEY")??"";
const SELKENT_BASE="https://www.selkent.org.uk";
const cors={
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods":"POST, OPTIONS",
  "Content-Type":"application/json"
};
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:cors});
const admin=()=>createClient(SUPABASE_URL,SERVICE_ROLE,{auth:{persistSession:false,autoRefreshToken:false}});
const anon=()=>createClient(SUPABASE_URL,ANON_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
function cleanText(s:string){return String(s||'').replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&#39;/g,"'").replace(/&quot;/gi,'"').replace(/\s+/g,' ').trim();}
function norm(s:string){return cleanText(s).toLowerCase().replace(/\bfootball club\b|\bfc\b|\bafc\b/g,' ').replace(/[^a-z0-9]+/g,' ').trim();}
function slugify(s:string){return norm(s).replace(/\s+/g,'-').replace(/^-+|-+$/g,'').slice(0,64)||'club';}
function htmlLines(html:string){return html.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<br\s*\/?>/gi,'\n').replace(/<\/(?:p|div|li|h1|h2|h3|h4|tr|td|section)>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&#39;/g,"'").replace(/&quot;/gi,'"').split(/\n+/).map(x=>x.replace(/\s+/g,' ').trim()).filter(Boolean);}
async function fetchHtml(url:string){const r=await fetch(url,{headers:{"User-Agent":"Mozilla/5.0 GrassrootsClubHub/2.2","Accept":"text/html,application/xhtml+xml"}});if(!r.ok)throw new Error(`Selkent returned HTTP ${r.status}`);return await r.text();}
function directoryClubs(html:string){const out:{id:string,name:string,url:string}[]=[];const seen=new Set<string>();for(const m of html.matchAll(/<a\b[^>]*href=["']([^"']*\/public\/clubs\/(\d+)(?:\/sub)?)["'][^>]*>([\s\S]*?)<\/a>/gi)){const id=m[2],name=cleanText(m[3]);if(!name||seen.has(id))continue;seen.add(id);out.push({id,name,url:`${SELKENT_BASE}/public/clubs/${id}/sub`});}return out;}
function bestClub(clubs:{id:string,name:string,url:string}[],q:string){const wanted=norm(q);if(!wanted)return null;let best:{id:string,name:string,url:string}|null=null;let bestScore=0;for(const c of clubs){const n=norm(c.name);let score=0;if(n===wanted)score=10000;else if(n.includes(wanted)||wanted.includes(n))score=7000+Math.min(n.length,wanted.length);else score=wanted.split(' ').filter(x=>n.includes(x)).length*100;if(score>bestScore){best=c;bestScore=score;}}return bestScore>0?best:null;}
function section(lines:string[],label:string,stops:string[]){const i=lines.findIndex(x=>x.toLowerCase()===label.toLowerCase());if(i<0)return[];const stop=new Set(stops.map(x=>x.toLowerCase()));const out:string[]=[];for(let j=i+1;j<lines.length;j++){if(stop.has(lines[j].toLowerCase()))break;out.push(lines[j]);}return out;}
function parseSelkentClub(html:string,club:{id:string,name:string,url:string}){const lines=htmlLines(html);const stops=['Other Grounds','Other Ground','Club Colours','Website','Map','Committee','Teams','Players Wanted','Details'];const home=section(lines,'Home Ground',stops);const colours=section(lines,'Club Colours',['Website','Map','Committee','Teams','Players Wanted','Details']);const teamLines=section(lines,'Teams',['Players Wanted','Details','Committee','Map']);const teams:any[]=[];for(const raw of teamLines){const m=raw.match(/^Under\s+(\d+)(?:s)?\s+(.+)$/i);if(!m)continue;const age=Number(m[1]);const name=m[2].trim();if(age>=5&&age<=18&&name)teams.push({age_group:age,name,provider_label:raw,division:'',league_name:`${club.name} ${name}`});}return {club_id:club.id,club_name:club.name,club_url:club.url,home_ground:{name:home[0]||'',address:home[1]||''},club_colours:colours[0]||'',teams};}
async function lookupSelkent(q:string){const dir=await fetchHtml(`${SELKENT_BASE}/public/clubs/directory`);const clubs=directoryClubs(dir);const picked=bestClub(clubs,q);if(!picked)throw new Error('Club not found in the Selkent directory');const html=await fetchHtml(picked.url);return parseSelkentClub(html,picked);}
function defaultRule(age:number){if(age<=9)return {age_group:age,format:'5v5',players_on_pitch:5,max_registered:10,matchday_max:10,rolling_substitutions:true};if(age<=11)return {age_group:age,format:'7v7',players_on_pitch:7,max_registered:14,matchday_max:14,rolling_substitutions:true};if(age<=13)return {age_group:age,format:'9v9',players_on_pitch:9,max_registered:16,matchday_max:14,rolling_substitutions:false};return {age_group:age,format:'11v11',players_on_pitch:11,max_registered:18,matchday_max:16,rolling_substitutions:false};}
function dataUrlBytes(dataUrl:string){const m=String(dataUrl||'').match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);if(!m)return null;const raw=atob(m[2]);const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return {mime:m[1],bytes,ext:m[1]==='image/png'?'png':m[1]==='image/webp'?'webp':'jpg'};}

Deno.serve(async(req:Request)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  if(req.method!=='POST')return json({error:'Method not allowed'},405);
  if(!SUPABASE_URL||!SERVICE_ROLE||!ANON_KEY)return json({error:'Onboarding service is not configured'},500);
  let body:any;try{body=await req.json();}catch{return json({error:'Invalid request'},400);}
  const action=String(body?.action||'').toLowerCase();
  try{
    if(action==='lookup_selkent'){
      const q=String(body?.query||'').trim().slice(0,100);if(q.length<2)return json({error:'Enter a club name'},400);
      return json(await lookupSelkent(q));
    }
    if(action==='create_club'){
      const club=body?.club||{},provider=body?.provider||{},adminInput=body?.admin||{};
      const displayName=String(club.display_name||'').trim().replace(/\s+/g,' ').slice(0,100);
      const adminName=String(adminInput.full_name||'').trim().replace(/\s+/g,' ').slice(0,80);
      const email=String(adminInput.email||'').trim().toLowerCase();const password=String(adminInput.password||'');
      if(displayName.length<2)return json({error:'Enter your club name'},400);
      if(adminName.length<2)return json({error:'Enter the Club Admin name'},400);
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json({error:'Enter a valid admin email address'},400);
      if(password.length<8)return json({error:'Use at least 8 characters for the admin password'},400);
      let teams=Array.isArray(body?.teams)?body.teams:[];
      let providerConfig:any=provider?.config&&typeof provider.config==='object'?provider.config:{};
      const providerKey=String(provider?.key||'manual').toLowerCase()==='selkent'?'selkent':'manual';
      if(providerKey==='selkent'&&(!teams.length||!providerConfig?.club_url)){
        const found=await lookupSelkent(String(providerConfig.lookup_query||displayName));
        providerConfig={...providerConfig,club_id:found.club_id,club_name:found.club_name,club_url:found.club_url,home_ground:found.home_ground,club_colours:found.club_colours};
        if(!teams.length)teams=found.teams;
      }
      teams=teams.map((t:any)=>({age_group:Number(t.age_group),name:String(t.name||'').trim().slice(0,80),division:String(t.division||'').trim().slice(0,80),provider_label:String(t.provider_label||'').trim().slice(0,120),league_name:String(t.league_name||'').trim().slice(0,140)})).filter((t:any)=>t.age_group>=5&&t.age_group<=18&&t.name);
      if(!teams.length)return json({error:'Add at least one team'},400);if(teams.length>60)return json({error:'A maximum of 60 teams can be created during onboarding'},400);
      const ages=[...new Set(teams.map((t:any)=>t.age_group))].sort((a:number,b:number)=>a-b);
      const suppliedRules=Array.isArray(body?.rules)?body.rules:[];const ruleMap=new Map(suppliedRules.map((r:any)=>[Number(r.age_group),r]));
      const publishFrom=club.results_publish_from_age==null?null:Number(club.results_publish_from_age);const playerAges=Array.isArray(club.player_account_age_groups)?club.player_account_age_groups.map(Number):[];
      const rules=ages.map((age:number)=>{const d=defaultRule(age),s:any=ruleMap.get(age)||{};return {...d,...s,age_group:age,results_published:s.results_published??(publishFrom!=null&&age>=publishFrom),player_accounts_allowed:s.player_accounts_allowed??playerAges.includes(age),stats_config:s.stats_config||{goals:true,assists:true,awards:true,bookings:age>=11}};});
      const a=admin();let slug=slugify(String(club.slug||displayName));const {data:existing}=await a.from('club_settings').select('slug').eq('slug',slug).maybeSingle();if(existing)slug=`${slug}-${crypto.randomUUID().replace(/-/g,'').slice(0,5)}`;
      const {data:created,error:createErr}=await a.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{full_name:adminName,club_onboarding:true}});if(createErr||!created?.user)return json({error:createErr?.message||'Could not create the Club Admin account'},400);
      const userId=created.user.id;let provision:any=null;
      try{
        const payload={slug,display_name:displayName,short_name:String(club.short_name||'').trim().slice(0,24),current_season:String(club.current_season||'2026/27').trim(),timezone:String(club.timezone||'Europe/London'),country_code:String(club.country_code||'GB').toUpperCase(),primary_color:String(club.primary_color||'#218a21'),secondary_color:String(club.secondary_color||'#ffffff'),accent_color:String(club.accent_color||club.primary_color||'#218a21'),provider_key:providerKey,provider_config:providerConfig,admin_name:adminName,is_demo:Boolean(club.is_demo),teams,rules,config:{onboarding_version:1,beta:true}};
        const {data,error}=await a.rpc('provision_club_tenant',{p_user_id:userId,p_payload:payload});if(error)throw error;provision=data;
        const logo=dataUrlBytes(String(club.logo_data_url||''));if(logo&&logo.bytes.length<=1048576){const path=`clubs/${provision.club_id}/logo.${logo.ext}`;const up=await a.storage.from('club-assets').upload(path,logo.bytes,{contentType:logo.mime,upsert:true});if(!up.error){const {data:pub}=a.storage.from('club-assets').getPublicUrl(path);await a.from('club_settings').update({logo_url:pub.publicUrl,updated_at:new Date().toISOString()}).eq('club_id',provision.club_id);provision.logo_url=pub.publicUrl;}}
      }catch(e){try{await a.auth.admin.deleteUser(userId);}catch{}throw e;}
      const {data:signed,error:signErr}=await anon().auth.signInWithPassword({email,password});if(signErr||!signed?.session)return json({ok:true,club:provision,sign_in_required:true});
      return json({ok:true,club:provision,session:signed.session});
    }
    if(action==='delete_demo_club'){
      const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'');if(!token)return json({error:'Sign in required'},401);
      const a=admin();const {data:userData,error:userErr}=await a.auth.getUser(token);if(userErr||!userData?.user)return json({error:'Sign in required'},401);
      const uid=userData.user.id;const {data:profile}=await a.from('profiles').select('club_id,role').eq('user_id',uid).single();if(!profile||profile.role!=='club_admin'||!profile.club_id)return json({error:'Club Admin access required'},403);
      const {data:settings}=await a.from('club_settings').select('is_demo,display_name').eq('club_id',profile.club_id).single();if(!settings?.is_demo)return json({error:'Only demo clubs can be deleted here'},403);
      const {data:members}=await a.from('profiles').select('user_id').eq('club_id',profile.club_id);const {error:delErr}=await a.rpc('delete_demo_club_tenant',{p_club_id:profile.club_id});if(delErr)throw delErr;
      for(const m of members||[]){try{await a.auth.admin.deleteUser(m.user_id);}catch{}}
      return json({ok:true,deleted:settings.display_name});
    }
    return json({error:'Unknown onboarding action'},400);
  }catch(e){return json({error:(e as any)?.message||String(e)},400);}
});
