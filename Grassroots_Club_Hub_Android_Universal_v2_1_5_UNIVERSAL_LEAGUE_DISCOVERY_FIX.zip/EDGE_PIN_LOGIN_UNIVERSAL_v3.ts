import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:cors});
const norm=(s:unknown)=>String(s??"").toLowerCase().replace(/[^a-z0-9]+/g," ").trim().replace(/\s+/g," ");
// Keep the existing password transform for backwards compatibility with existing PIN accounts.
const pinPassword=(pin:string)=>`SHFC-PIN!${pin}#AFC`;

Deno.serve(async(req:Request)=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
  if(req.method!=="POST")return json({error:"Method not allowed"},405);
  if(!SUPABASE_URL||!SERVICE_ROLE||!ANON_KEY)return json({error:"Server authentication is not configured"},500);
  let body:any;try{body=await req.json();}catch{return json({error:"Invalid request"},400);}
  const clubInput=String(body?.club??"").trim().toLowerCase();
  const teamInput=String(body?.team??"").trim().slice(0,80);
  const name=String(body?.name??"").trim().replace(/\s+/g," ").slice(0,80);
  const pin=String(body?.pin??"").trim();
  if(name.length<2||teamInput.length<2||!/^\d{6}$/.test(pin))return json({error:"Club, team, name or PIN not recognised"},400);

  const admin=createClient(SUPABASE_URL,SERVICE_ROLE,{auth:{persistSession:false,autoRefreshToken:false}});
  const anon=createClient(SUPABASE_URL,ANON_KEY,{auth:{persistSession:false,autoRefreshToken:false}});

  let clubId:string|undefined;
  let clubDisplay:string|undefined;
  let clubSlug:string|undefined;
  if(clubInput){
    const {data:cs,error:csErr}=await admin.from("club_settings").select("club_id,slug,display_name,active").eq("slug",clubInput).eq("active",true).maybeSingle();
    if(csErr||!cs)return json({error:"Club, team, name or PIN not recognised"},400);
    clubId=cs.club_id;clubDisplay=cs.display_name;clubSlug=cs.slug;
  }

  let teamQuery=admin.from("teams").select("id,club_id,name,age_group,active").eq("active",true);
  if(clubId)teamQuery=teamQuery.eq("club_id",clubId);
  const {data:teams,error:teamErr}=await teamQuery;
  if(teamErr)return json({error:"Access service is temporarily unavailable"},500);
  const wanted=norm(teamInput);
  const matches=(teams||[]).filter((t:any)=>{
    const n=norm(t.name), full=norm(`U${t.age_group} ${t.name}`), full2=norm(`Under ${t.age_group} ${t.name}`);
    return wanted===n||wanted===full||wanted===full2;
  });
  if(matches.length!==1)return json({error:"Club, team, name or PIN not recognised"},400);
  const team=matches[0];

  if(!clubId){
    const {data:cs}=await admin.from("club_settings").select("slug,display_name").eq("club_id",team.club_id).maybeSingle();
    clubSlug=cs?.slug;clubDisplay=cs?.display_name;
  }

  const {data:profiles,error:profileErr}=await admin.from("profiles").select("user_id,full_name,role,pin_set_at,pin_reset_required,pin_failed_attempts,pin_locked_until").eq("team_id",team.id).in("role",["parent","player"]);
  if(profileErr)return json({error:"Access service is temporarily unavailable"},500);
  const people=(profiles||[]).filter((p:any)=>norm(p.full_name)===norm(name));
  if(people.length!==1||!people[0].pin_set_at)return json({error:"Club, team, name or PIN not recognised"},400);
  const profile=people[0];
  if(profile.pin_locked_until&&new Date(profile.pin_locked_until).getTime()>Date.now())return json({error:"Too many PIN attempts. Try again later or ask your coach to reset your PIN."},429);

  const {data:userData,error:userErr}=await admin.auth.admin.getUserById(profile.user_id);
  const email=userData?.user?.email||"";
  if(userErr||!email)return json({error:"Club, team, name or PIN not recognised"},400);
  const {data:signed,error:signErr}=await anon.auth.signInWithPassword({email,password:pinPassword(pin)});
  if(signErr||!signed?.session){
    const attempts=Math.min(20,Number(profile.pin_failed_attempts||0)+1);
    const lock=attempts>=5?new Date(Date.now()+15*60*1000).toISOString():null;
    await admin.from("profiles").update({pin_failed_attempts:attempts,pin_locked_until:lock}).eq("user_id",profile.user_id);
    return json({error:lock?"Too many PIN attempts. Try again in 15 minutes or ask your coach to reset your PIN.":"Club, team, name or PIN not recognised"},lock?429:400);
  }
  await admin.from("profiles").update({pin_failed_attempts:0,pin_locked_until:null}).eq("user_id",profile.user_id);
  return json({session:signed.session,display_name:profile.full_name,role:profile.role,club:{slug:clubSlug||null,display_name:clubDisplay||null},team:{id:team.id,name:team.name,age_group:team.age_group},pin_reset_required:Boolean(profile.pin_reset_required)});
});
