UNIVERSAL CORE V1 / Android 2.1.4

This build installs alongside the Shooters Hill production app (applicationId com.grassrootsclubhub.universal).
It reads club branding, competition rules and provider configuration from Supabase.
Debug Quick Test offers Shooters Hill AFC and Greenwich United FC demo tenants.

Shooters Hill Team Tracker Android Cloud v2.0.35

Android package
  com.shootershill.valiants

Version
  2.0.35 (versionCode 2035)

Build
  The GitHub Action extracts this ZIP and runs:
    gradle :app:assembleDebug

v2.0.32 highlights
- Debug-only Quick Test Login on the opening screen. It enters U9 Valiants Coach TEST MODE using local data only; cloud writes are disabled and the button is not available in release builds.
- Match availability deadlines are fixture-specific. Coaches can set a deadline and send reminders to outstanding linked parent/player accounts.
- New in-app notification centre with unread badge for club notices, availability requests/reminders, fixture changes, squad selection, access approval and completed match-report updates.
- Matchday squad can notify only linked accounts for selected players.
- Fixture changes create a read-only notification for parents/players as well as requiring coach reconfirmation.
- Attendance now drives season appearance statistics.
- U8-U11 attendance remains Present / Not present.
- U12+ completed-match attendance uses Started / Substitute / Unavailable / No-show so starts and appearances can be calculated accurately.
- Player profiles and the season contribution table now include appearances, attendance percentage and U12+ starts/sub appearances.
- Native Add to calendar action opens the device calendar pre-filled with opponent, kick-off, location, competition and kit note.
- Saving a completed match report notifies team parent/player accounts that updated stats and attendance are available.

Previous retained features
- U15-and-below read-only player accounts and shared parent/player availability response.
- Same-age Selkent opponent directory.
- Light / Dark / System appearance.
- Editable non-league Friendly/Tournament results.
- Club announcements and grouped Admin health dashboard.
- Parent PIN onboarding/reset and team dropdown login.
- Fixture-specific tactics, matchday dashboard and coach-controlled parent-player links.
- U12+ publication rule and mini-soccer score entry.


v2.0.33 changes
-----------------
- Club Admin Results now use the complete internal played-match history for every team/age, including friendlies, tournaments and Mini-Soccer scores that Selkent does not publish.
- Coach/Assistant Coach Club Results remain restricted to Selkent-published results (U12+).
- Player app access/invites are restricted to U15 squads only in both UI and Supabase functions.
- Dark-mode contrast hardened across forms, labels, match cards, tabs, tables, notifications and secondary text.


v2.0.34 changes
- Season archive and Club Admin rollover with read-only archived season viewer.
- Audit history for key match, attendance, access, fixture and tactics changes.
- Proper tournament event mode with tournament squad, grouped games and event W/D/L GF/GA.


v2.0.35 changes
- Restored Add match button on Matches.
- Scheduled match cards now expose Edit fixture.
- Admin Results no longer re-renders Club at a glance underneath age-group results.
- Expanded dark-mode contrast coverage across match details, admin cards, status pills, tables and secondary text.


Universal onboarding v2.1.1:
- Native Android image chooser for club badge uploads.
- Mobile-first 7-step onboarding layout.
- Selkent club directory import.
- FA Full-Time public league/division URL import.
- Manual provider remains available.


Universal onboarding v2.1.2:
- Android badge picker now uses ACTION_OPEN_DOCUMENT with image MIME filters and URI handling.
- Replaced native file control with a consistent Choose badge button.
- Onboarding layout hardened for phone/WebView widths; rules fields no longer overflow and card text remains readable.
- FA provider onboarding route: official County FA directory -> FA Full-Time league search -> import league/team information.
- Includes EDGE_FA_LEAGUE_DISCOVERY_v2.ts for the deployed County FA → Full-Time discovery route (Supabase function version 2).
- FA Full-Time providers now refresh public fixtures/results and available standings automatically in Android, using the selected team/league source in the same sync cycle as Selkent.


Universal onboarding v2.1.3:
- Club name is optional at the start; it can be identified from the selected league/team.
- FA Full-Time flow is now County FA -> league -> team search -> club auto-detection.
- Selecting a team fills the official club name, keeps the provider team/source link and imports other matching club teams found in that league.
- Selkent club selection now also replaces the provisional club name with the directory name and imports its teams automatically.
- Team review remains before rules so ages/divisions can be corrected or unwanted teams unticked.

Universal onboarding v2.1.4:
- FA onboarding now uses a direct County FA -> league -> club selection flow.
- Club search groups Full-Time team records by their inferred official club, so users select the club rather than a single team.
- Selecting a club imports all matching associated teams exposed by the selected Full-Time league, including age groups, divisions and source links.
- Preserves Full-Time team source links so each imported team can continue to sync its own fixtures/results after onboarding.
- Club name remains optional on step 1 and is overwritten by the selected official club name.
