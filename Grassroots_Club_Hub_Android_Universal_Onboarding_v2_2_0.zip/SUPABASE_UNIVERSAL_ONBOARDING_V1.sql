-- Grassroots Club Hub - Self-Service Club Onboarding v1
-- Universal tenant provisioning and safer new-user bootstrap.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_bootstrap_email text;
  v_bootstrap_club uuid;
begin
  select trim(both '"' from value::text)
    into v_bootstrap_email
    from public.app_config
   where key='bootstrap_admin_email';

  select cs.club_id
    into v_bootstrap_club
    from public.club_settings cs
   where cs.slug='shooters-hill-afc'
   limit 1;

  insert into public.profiles(user_id,club_id,full_name,role,access_method)
  values(
    new.id,
    case when lower(coalesce(new.email,''))=lower(coalesce(v_bootstrap_email,'')) then v_bootstrap_club else null end,
    coalesce(nullif(new.raw_user_meta_data->>'full_name',''), split_part(coalesce(new.email,''),'@',1), 'New user'),
    case when lower(coalesce(new.email,''))=lower(coalesce(v_bootstrap_email,'')) then 'club_admin' else 'pending' end,
    'email'
  )
  on conflict (user_id) do nothing;
  return new;
end
$$;

create or replace function public.provision_club_tenant(p_user_id uuid, p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_club uuid;
  v_slug text := lower(trim(coalesce(p_payload->>'slug','')));
  v_display text := trim(coalesce(p_payload->>'display_name',''));
  v_short text := trim(coalesce(p_payload->>'short_name',''));
  v_season text := trim(coalesce(p_payload->>'current_season','2026/27'));
  v_timezone text := trim(coalesce(p_payload->>'timezone','Europe/London'));
  v_country text := upper(trim(coalesce(p_payload->>'country_code','GB')));
  v_primary text := coalesce(p_payload->>'primary_color','#218a21');
  v_secondary text := coalesce(p_payload->>'secondary_color','#ffffff');
  v_accent text := coalesce(p_payload->>'accent_color',v_primary);
  v_provider text := lower(trim(coalesce(p_payload->>'provider_key','manual')));
  v_admin_name text := trim(coalesce(p_payload->>'admin_name','Club Admin'));
  v_publish_from int;
  v_player_ages int[] := '{}';
  v_demo boolean := coalesce((p_payload->>'is_demo')::boolean,false);
  v_provider_config jsonb := coalesce(p_payload->'provider_config','{}'::jsonb);
  v_config jsonb := coalesce(p_payload->'config','{}'::jsonb);
  t jsonb;
  r jsonb;
  v_age int;
  v_name text;
  v_division text;
  v_label text;
  v_league text;
begin
  if current_setting('request.jwt.claim.role',true) <> 'service_role' then
    raise exception 'Service role required';
  end if;
  if p_user_id is null or not exists(select 1 from auth.users where id=p_user_id) then raise exception 'Admin account not found'; end if;
  if length(v_display)<2 or length(v_display)>100 then raise exception 'Club name must be 2-100 characters'; end if;
  if v_slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' or length(v_slug)<2 or length(v_slug)>80 then raise exception 'Invalid club slug'; end if;
  if v_provider not in ('manual','selkent') then raise exception 'Unsupported competition provider'; end if;
  if jsonb_typeof(p_payload->'teams') <> 'array' or jsonb_array_length(p_payload->'teams') < 1 then raise exception 'Add at least one team'; end if;
  if jsonb_array_length(p_payload->'teams') > 60 then raise exception 'Too many teams'; end if;
  if jsonb_typeof(p_payload->'rules') <> 'array' or jsonb_array_length(p_payload->'rules') < 1 then raise exception 'Competition rules are required'; end if;
  if exists(select 1 from public.club_settings where slug=v_slug) then raise exception 'That club address is already in use'; end if;

  insert into public.clubs(name,selkent_club_url)
  values(v_display, case when v_provider='selkent' then nullif(v_provider_config->>'club_url','') else null end)
  returning id into v_club;

  select min((x->>'age_group')::int) filter (where coalesce((x->>'results_published')::boolean,false))
    into v_publish_from
    from jsonb_array_elements(p_payload->'rules') x;

  select coalesce(array_agg((x->>'age_group')::int order by (x->>'age_group')::int),'{}'::int[])
    into v_player_ages
    from jsonb_array_elements(p_payload->'rules') x
   where coalesce((x->>'player_accounts_allowed')::boolean,false);

  insert into public.club_settings(
    club_id,slug,display_name,short_name,primary_color,secondary_color,accent_color,logo_asset,logo_url,
    current_season,timezone,country_code,default_provider_key,results_publish_from_age,player_account_age_groups,
    is_demo,active,config,updated_at
  ) values(
    v_club,v_slug,v_display,coalesce(nullif(v_short,''),left(v_display,16)),v_primary,v_secondary,v_accent,'',null,
    v_season,v_timezone,v_country,v_provider,v_publish_from,v_player_ages,v_demo,true,
    v_config || jsonb_build_object('sport','football','setup_completed',true,'created_via','self_service_onboarding_v1'),now()
  );

  insert into public.competition_providers(club_id,provider_key,provider_type,enabled,is_primary,config,updated_at)
  values(v_club,v_provider,v_provider,true,true,v_provider_config,now());

  for t in select value from jsonb_array_elements(p_payload->'teams') loop
    v_age := nullif(t->>'age_group','')::int;
    v_name := trim(coalesce(t->>'name',''));
    v_division := trim(coalesce(t->>'division',''));
    if v_age is null or v_age<5 or v_age>18 then raise exception 'Invalid team age group'; end if;
    if length(v_name)<1 or length(v_name)>80 then raise exception 'Invalid team name'; end if;
    v_label := coalesce(nullif(trim(t->>'provider_label'),''), format('Under %ss %s',v_age,v_name));
    v_league := coalesce(nullif(trim(t->>'league_name'),''), v_display||' '||v_name);
    insert into public.teams(club_id,name,age_group,division,season,selkent_label,league_name,active)
    values(v_club,v_name,v_age,v_division,v_season,v_label,v_league,true);
  end loop;

  for r in select value from jsonb_array_elements(p_payload->'rules') loop
    v_age := nullif(r->>'age_group','')::int;
    if v_age is null or v_age<5 or v_age>18 then raise exception 'Invalid rule age group'; end if;
    insert into public.competition_rules(
      club_id,age_group,format,players_on_pitch,max_registered,matchday_max,rolling_substitutions,
      results_published,player_accounts_allowed,stats_config,updated_at
    ) values(
      v_club,v_age,coalesce(nullif(r->>'format',''),'11v11'),
      greatest(1,coalesce((r->>'players_on_pitch')::int,11)),
      greatest(1,coalesce((r->>'max_registered')::int,18)),
      greatest(1,coalesce((r->>'matchday_max')::int,16)),
      coalesce((r->>'rolling_substitutions')::boolean,false),
      coalesce((r->>'results_published')::boolean,false),
      coalesce((r->>'player_accounts_allowed')::boolean,false),
      coalesce(r->'stats_config','{"goals":true,"assists":true,"awards":true,"bookings":true}'::jsonb),now()
    );
  end loop;

  update public.profiles
     set club_id=v_club, team_id=null, coach_team_id=null, full_name=v_admin_name, role='club_admin',
         access_method='email', approved_at=now(), approved_by=p_user_id, updated_at=now()
   where user_id=p_user_id;
  if not found then
    insert into public.profiles(user_id,club_id,full_name,role,access_method,approved_at,approved_by)
    values(p_user_id,v_club,v_admin_name,'club_admin','email',now(),p_user_id);
  end if;

  return jsonb_build_object('club_id',v_club,'slug',v_slug,'display_name',v_display,'team_count',jsonb_array_length(p_payload->'teams'));
exception when others then
  if v_club is not null then delete from public.clubs where id=v_club; end if;
  raise;
end
$$;

revoke all on function public.provision_club_tenant(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.provision_club_tenant(uuid,jsonb) to service_role;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('club-assets','club-assets',true,1048576,array['image/png','image/jpeg','image/webp'])
on conflict(id) do update set public=true,file_size_limit=1048576,allowed_mime_types=array['image/png','image/jpeg','image/webp'];
