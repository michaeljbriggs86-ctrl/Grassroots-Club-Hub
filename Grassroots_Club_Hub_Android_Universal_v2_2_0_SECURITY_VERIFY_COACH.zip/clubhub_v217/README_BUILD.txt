Grassroots Club Hub Android Universal v2.2.0

Application ID
  com.grassrootsclubhub.universal

Version
  2.2.0 (versionCode 2200)

Build
  Extract this ZIP and run:
    gradle :app:assembleDebug

Key architecture
- Club-first onboarding: Find my club automatically or Enter manually.
- Automatic setup searches the shared Grassroots Master Directory directly; County FA and league selection are no longer required.
- If a club is missing, the directory service checks the FA Full-Time public club source once, normalises the club/teams/leagues, stores them centrally, and returns the cached record.
- 50 County FA records are seeded in the directory as canonical geography/affiliation references.
- Selected directory club/team/provider IDs are carried into the created club workspace.
- Manual setup remains available for clubs or competitions without a public source.
- Debug Quick Test uses a generic Demo Juniors FC tenant with cloud writes disabled.
- No club-specific production examples or seed records are bundled in the universal app.

Onboarding order
  1. Setup method
  2. Find/select club or enter manually
  3. Branding
  4. Teams
  5. Football rules
  6. Club Admin
  7. Review / Create club

Create-club handoff
- First tap immediately shows Creating your club.
- Successful creation saves the session and uses the Android native reload bridge to open the authenticated Club Admin workspace.
