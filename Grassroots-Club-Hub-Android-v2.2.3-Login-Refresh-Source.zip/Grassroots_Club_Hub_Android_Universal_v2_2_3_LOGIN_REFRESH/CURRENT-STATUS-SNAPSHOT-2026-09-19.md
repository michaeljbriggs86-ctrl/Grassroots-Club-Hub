# Current Master Status Manifest — Grassroots Club Hub

**Checked:** 2026-09-19  
**Governing protocol:** `AI-COLLABORATION-PROTOCOL.md`

This file is the quick index for the canonical master folder. It does not replace
`ARCHITECTURE.md`.

## Canonical documents

- `AI-COLLABORATION-PROTOCOL.md` — current collaboration rules.
- `ARCHITECTURE.md` — current architecture/source-of-truth register.
- `CURRENT-STATUS-MANIFEST.md` — this index.

## Android

### v2.2.2 static-feed source

Status: **WRITTEN** and represented by the canonical source archive in this folder.

### v2.2.2 static-feed APK

Status: **BUILT** — verified by artifact inspection on 2026-09-19.

```text
APK SHA-256:
c38dea003e8f5f2342188fd5afa806b744cdf9a3275a2788aa4db09d5d84e246
```

Static directory and U12+ standings integration are **BUILT**.

Status: **DEPLOYED-LIVE — NOT VERIFIED**.

Native allowlist security review: **NOT VERIFIED** as of 2026-09-19. The exact
GitHub Raw allowlist is present in the BUILT artifact, but no separate deliberate
security-review evidence has been produced.

### Legacy APK (11)

Status: **BUILT** legacy 2.2.1 artifact.

```text
ZIP SHA-256:
1e4bf9565683c9f7edf9be6afdb1719a8fcd83c84190381c62bc53e95adeda5d

inner APK SHA-256:
b18199a2fb9de325d3353254fbacdeb07faaa973920c31be244300937c88455f
```

It does not contain `static-feed-overlay.js` and is retained only as historical
evidence in the archive.

## Backend

Status: **DEPLOYED-LIVE** — last verified 2026-09-18 by the live backend export.

Legacy SQL/Edge files are **WRITTEN** historical references only.

## Obsolete planning documents

`TODO-SYNC-INTEGRATION.md` is superseded. Its old “PLANNED” status no longer
describes the Android 2.2.2 source because that integration is now **BUILT**.
The TODO is retained in the archive only for provenance.

## Release pipeline

Status: **PLANNED** — consolidate to one authoritative APK release workflow and
require artifact inspection before any DEPLOYED-LIVE claim.

Repository evidence snapshot `main @ 302508c`, checked 2026-09-19, still contains
base64-embedded Java/JavaScript inside `build-apk-static-feed.yml`. That snapshot
is evidence only and is not canonical source. A readable replacement workflow is
WRITTEN in the protocol-applied source handoff; actual GitHub replacement remains
**PLANNED** until the repository file is changed and verified.

## Legal/privacy working documents

Status: **PLANNED** — checked 2026-09-19.

The Privacy Policy working copy currently says players never have app access at
any age, while the current app/backend design permits U15-only player access. The
file has been renamed to flag the conflict. This is unresolved and must go to Mike;
do not treat the working privacy policy or DPA as DEPLOYED-LIVE legal documents.
