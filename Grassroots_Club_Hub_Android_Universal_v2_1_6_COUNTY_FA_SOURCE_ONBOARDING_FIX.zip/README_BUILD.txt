UNIVERSAL CORE V1 / Android 2.1.6

This build installs alongside the Shooters Hill production app (applicationId com.grassrootsclubhub.universal).
It reads club branding, competition rules and provider configuration from Supabase.
Debug Quick Test offers Shooters Hill AFC and Greenwich United FC demo tenants.

Shooters Hill Team Tracker Android Cloud v2.0.35

Android package
  com.shootershill.valiants

Version
  2.0.35 (versionCode 2035)

Build
  The GitHub Action extracts this ZIP and runs:
    gradle :app:assembleDebug

v2.0.32 highlights
- Debug-only Quick Test Login on the opening screen. It enters U9 Valiants Coach TEST MODE using local data only; cloud writes are disabled and the button is not available in release builds.
- Match availability deadlines are fixture-specific. Coaches can set a deadline and send reminders to outstanding linked parent/player accounts.
- New in-app notification centre with unread badge for club notices, availability requests/reminders, fixture changes, squad selection, access approval and completed match-report updates.
- Matchday squad can notify only linked accounts for selected players.
- Fixture changes create a read-only notification for parents/players as well as requiring coach reconfirmation.
- Attendance now drives season appearance statistics.
- U8-U11 attendance remains Present / Not present.
- U12+ completed-match attendance uses Started / Substitute / Unavailable / No-show so starts and appearances can be calculated accurately.
- Player profiles and the season contribution table now include appearances, attendance percentage and U12+ starts/sub appearances.
- Native Add to calendar action opens the device calendar pre-filled with opponent, kick-off, location, competition and kit note.
- Saving a completed match report notifies team parent/player accounts that updated stats and attendance are available.

Previous retained features
- U15-and-below read-only player accounts and shared parent/player availability response.
- Same-age Selkent opponent directory.
- Light / Dark / System appearance.
- Editable non-league Friendly/Tournament results.
- Club announcements and grouped Admin health dashboard.
- Parent PIN onboarding/reset and team dropdown login.
- Fixture-specific tactics, matchday dashboard and coach-controlled parent-player links.
- U12+ publication rule and mini-soccer score entry.


v2.0.33 changes
-----------------
- Club Admin Results now use the complete internal played-match history for every team/age, including friendlies, tournaments and Mini-Soccer scores that Selkent does not publish.
- Coach/Assistant Coach Club Results remain restricted to Selkent-published results (U12+).
- Player app access/invites are restricted to U15 squads only in both UI and Supabase functions.
- Dark-mode contrast hardened across forms, labels, match cards, tabs, tables, notifications and secondary text.


v2.0.34 changes
- Season archive and Club Admin rollover with read-only archived season viewer.
- Audit history for key match, attendance, access, fixture and tactics changes.
- Proper tournament event mode with tournament squad, grouped games and event W/D/L GF/GA.


v2.0.35 changes
- Restored Add match button on Matches.
- Scheduled match cards now expose Edit fixture.
- Admin Results no longer re-renders Club at a glance underneath age-group results.
- Expanded dark-mode contrast coverage across match details, admin cards, status pills, tables and secondary text.


Universal onboarding v2.1.1:
- Native Android image chooser for club badge uploads.
- Mobile-first 7-step onboarding layout.
- Selkent club directory import.
- FA Full-Time public league/division URL import.
- Manual provider remains available.


Universal onboarding v2.1.2:
- Android badge picker now uses ACTION_OPEN_DOCUMENT with image MIME filters and URI handling.
- Replaced native file control with a consistent Choose badge button.
- Onboarding layout hardened for phone/WebView widths; rules fields no longer overflow and card text remains readable.
- FA provider onboarding route: official County FA directory -> FA Full-Time league search -> import league/team information.
- Includes EDGE_FA_LEAGUE_DISCOVERY_v2.ts for the deployed County FA → Full-Time discovery route (Supabase function version 2).
- FA Full-Time providers now refresh public fixtures/results and available standings automatically in Android, using the selected team/league source in the same sync cycle as Selkent.


Universal onboarding v2.1.3:
- Club name is optional at the start; it can be identified from the selected league/team.
- FA Full-Time flow is now County FA -> league -> team search -> club auto-detection.
- Selecting a team fills the official club name, keeps the provider team/source link and imports other matching club teams found in that league.
- Selkent club selection now also replaces the provisional club name with the directory name and imports its teams automatically.
- Team review remains before rules so ages/divisions can be corrected or unwanted teams unticked.


Universal onboarding v2.1.4:
- Fix Create club account handoff: successful creation now boots the authenticated Club Admin dashboard immediately in-process.
- Removes the delayed WebView reload that could wait for another user tap before navigation.
- Keeps a hard-navigation fallback if authenticated bootstrap does not complete within 10 seconds.
- Service-worker cache bumped to v214.


Universal onboarding v2.1.5:
- Removed Selkent as a top-level/default onboarding choice. Universal setup now starts with Find automatically or Manual setup.
- County FA list is canonicalised and de-duplicated to the 50 County FAs published by The FA.
- Selecting a County FA now automatically loads matching league options instead of requiring a league name first.
- League search now works across FA Full-Time plus registered non-Full-Time provider adapters; Selkent is discovered as a London FA league source rather than presented as a special default.
- Selecting a league then exposes the appropriate team/club search and keeps the same club/team autopopulation flow.
- Service-worker cache bumped to v215 and Android version bumped to 2.1.5 / versionCode 2105.


Universal onboarding v2.1.6:
- Reordered onboarding so setup method is step 1: Find automatically or Enter manually.
- Automatic setup now follows The FA County FA directory -> selected County FA website -> that County FA's own league directory/list -> league -> team/club.
- County league discovery no longer uses a global Full-Time league search. It crawls County FA league pages and linked league-list spreadsheets, including external leagues and FA Full-Time links.
- County FA list remains canonical and de-duplicated before display.
- Choosing a County FA immediately triggers its league-directory lookup; the search box now filters those County FA-sourced results only.
- Selkent is no longer seeded as a London/default result; it only appears when discovered in the London FA league data.
- External league sites remain selectable, with manual team entry as the fallback when no supported public team directory is exposed.
- Create club now moves to a dedicated Creating your club screen on the first tap, then immediately hands off to the authenticated Club Admin dashboard when the account returns.
- Authenticated boot now retries if the initial app boot is still completing, removing the second-tap/navigation race.
- Service-worker cache bumped to v216 and Android version bumped to 2.1.6 / versionCode 2106.
- Supabase fa-league-discovery deployed as v4 with County FA website and XLS/XLSX league-list parsing.
