# Grassroots Club Hub — Data Architecture Reference

**Document state:** Current governing architecture reference  
**Last updated:** 2026-09-19  
**Collaboration rules:** `AI-COLLABORATION-PROTOCOL.md`

This document governs data scope, source-of-truth decisions, Selkent integration,
Android acquisition, private/public boundaries, identity, publication safety,
and migration/cutover rules.

All feature/integration status claims use the protocol vocabulary:
**PLANNED / WRITTEN / TESTED / BUILT / DEPLOYED-LIVE**.
A BUILT or DEPLOYED-LIVE claim must be backed by the actual artifact or running
system, not only source code or a workflow definition.

---

# 0. Revision and conflict protocol

Before implementation continues, revise this document whenever architecture and
observed reality diverge.

If two documents or two AIs make conflicting status claims:

1. record the conflict;
2. inspect the same underlying evidence;
3. update this canonical document;
4. only then continue implementation.

`00 - CURRENT MASTER` is the canonical document location. Planning/TODO copies
that conflict with this file must be marked superseded or archived.

---

# 1. Current evidence-backed status — checked 2026-09-19

| Area | Status | Evidence / boundary |
|---|---|---|
| Static Android directory integration | **BUILT** | APK `Grassroots-Club-Hub-v2.2.2-static-feed.apk` inspected 2026-09-19; `assets/static-feed-overlay.js` present and referenced by `index.html`. |
| Static Android standings integration | **BUILT** | Same inspected 2.2.2 APK; overlay uses schema-v2 `data/results.json`. |
| Static Android directory/standings cutover | **DEPLOYED-LIVE: NOT VERIFIED** | The previously downloaded/shipping `Grassroots-Club-Hub-APK (11).zip` is 2.2.1 and does not contain the overlay. Do not claim cutover until the actual distributed/installed APK is verified. |
| Static fixtures cutover | **PLANNED** | Built 2.2.2 retains the temporary live Selkent fixture fallback because populated provider fixture markup has not yet been verified. |
| Static published-results cutover | **PLANNED** | Built 2.2.2 retains the temporary live Selkent result fallback because populated provider result markup has not yet been verified. |
| Public static feed parser/generalisation | **TESTED** | Production-run evidence dated 2026-09-19 recorded 15 age groups, 54 standings divisions, 320 rows and 20/20 tests; current GitHub availability was not independently re-verified during this protocol pass. |
| Private Supabase backend contract | **DEPLOYED-LIVE** | Verified by `LIVE_BACKEND_EXPORT_Shooters_Hill_Team_Tracker_2026-09-18`, captured directly from the live project on 2026-09-18. |
| Legacy backend files in the Android source archive | **WRITTEN** historical reference | They are not the canonical live backend and must not be redeployed as current state. |

Artifact fingerprints used for the Android check:

```text
Grassroots-Club-Hub-APK (11).zip SHA-256
1e4bf9565683c9f7edf9be6afdb1719a8fcd83c84190381c62bc53e95adeda5d

APK (11) inner APK SHA-256
b18199a2fb9de325d3353254fbacdeb07faaa973920c31be244300937c88455f

v2.2.2 static-feed APK SHA-256
c38dea003e8f5f2342188fd5afa806b744cdf9a3275a2788aa4db09d5d84e246
```

---

# 2. Single Source-of-Truth Register

There must be only one intended authority per category. A migration fallback may
exist temporarily, but it must not silently overwrite the intended authority.

## 2.1 Public Selkent club directory and division membership

Intended authoritative path:

```text
Selkent
  ↓
scripts/scrape_directory.py
  ↓
data/directory.json
```

Coverage:

- all discovered Selkent age groups;
- club directory;
- division/team membership;
- team-to-club links.

Update cadence: weekly.

Android integration of this authority is **BUILT** in v2.2.2, but
**DEPLOYED-LIVE is not verified** as of 2026-09-19.

## 2.2 U12+ league standings

Intended authoritative path:

```text
Selkent /public/resultsTable/{division_id}
  ↓
scripts/selkent_results.py
  ↓
scripts/scrape.py
  ↓
data/results.json
  ↓
Android app
```

Scope: U12+ only.

Android integration is **BUILT** in v2.2.2, but **DEPLOYED-LIVE is not verified**
as of 2026-09-19.

The Android app must not calculate an invented official position. Source
`row_order` may be displayed, but it is not an official position field.

## 2.3 Fixtures

Intended final authority:

```text
Selkent → scripts/scrape.py → data/results.json
```

Scope: all ages.

Status: **PLANNED** for static cutover.

The empty provider fixture shape has been tested, but populated fixture markup
has not yet been verified. Therefore the 2.2.2 Android build retains a temporary
live Selkent fixture fallback. It must remain isolated from static standings and
directory state.

## 2.4 Published match results

Intended final authority:

```text
Selkent → scripts/scrape.py → data/results.json
```

Scope: U12+ only.

Status: **PLANNED** for static cutover.

Age/division discovery and empty-result states have been tested; real populated
result-row markup still requires capture and verification. U7-U11 public results
must never be published.

## 2.5 Private club-entered results, player, roster and safeguarding data

Authoritative source:

```text
Supabase only
```

The backend contract was **DEPLOYED-LIVE** and verified on 2026-09-18 via the
live backend export.

GitHub static data must never contain:

- player rosters;
- parent/player links;
- emergency contacts;
- medical information or allergies;
- private attendance;
- safeguarding concerns or exports;
- private coach notes;
- private U7-U11 results.

## 2.6 Dormant/legacy Selkent systems

Older Supabase Selkent ingestion and legacy Android live acquisition may exist as
migration/reference systems. They are not allowed to become a competing
production authority without revising this document first.

---

# 3. Selkent standings contract

Verified endpoint:

```text
/public/resultsTable/{division_id}
```

Verified columns:

```text
Team
Played
Won
Drawn
Lost
GF
GA
Points
```

Rows may preserve:

- `row_order`;
- `provider_team_id`;
- provider division ID;
- team name;
- played/won/drawn/lost/GF/GA/points;
- update/disclaimer text where available.

`row_order` is not an official `position`. Do not invent tiebreak rules or goal
difference ordering.

Synthetic non-zero parser tests are **TESTED**. Real non-zero table spot-checking
remains **PLANNED** when a real non-zero source appears.

---

# 4. Identity rules

Canonical Selkent club identity comes from `/public/clubs/{id}`.

A results-table `data-team-id` is a provider team ID, not a club ID, and may vary
across age groups/divisions. It must not replace canonical club identity.

For private `public.teams`, one logical team for one season is:

```text
club_id + season + age_group + normalized team display name
```

`selkent_label` is mutable import/display metadata, not a stable identity key.

The duplicate-team repair recorded on 2026-09-19 is **DEPLOYED-LIVE** only to the
extent demonstrated by the live database evidence for that migration. Any future
claim about its continuing state must be rechecked against the database.

---

# 5. Update frequencies

| Data type | Intended frequency |
|---|---|
| Club/team directory | Weekly |
| Fixtures | Daily |
| Published U12+ results | Daily |
| U12+ standings | Daily |
| Private club-entered results | Immediate user action |
| Player/safeguarding data | Immediate user action |

The documented Selkent GitHub workflow is intended to execute parser tests before
publication and prefer stale known-good data over corrupt replacement data.

---

# 6. Publication safety

For public static feeds:

- collect before publishing;
- publish atomically;
- fail closed on unverified populated provider markup;
- preserve the existing known-good file if collection/parsing fails;
- never merge private Supabase data into public JSON.

For `data/directory.json`, a failed required scrape must not replace the known-good
directory.

---

# 7. U7-U11 public-result boundary

Grassroots Club Hub architecture requires:

```text
public Selkent results/standings: U12+
private club-entered results: U7-U11 allowed only inside authenticated club scope
```

Private younger-age results must never appear in public JSON or unauthenticated
views.

Safeguarding data remains Supabase-only and access-controlled.

---

# 8. Synthetic/test data

Synthetic fixtures must:

- start with `SYNTHETIC_`;
- contain `SYNTHETIC TEST FIXTURE — NOT REAL SELKENT DATA`;
- use obviously fictional names/IDs;
- state whether the markup is verified or inferred.

Synthetic parser success is **TESTED** evidence only and must not be described as
production verification.

---

# 9. Android integration

Final intended flow:

```text
Selkent
   ↓
GitHub Actions
   ↓
validated static JSON
   ↓
Android app
```

Static host/repository/paths implemented in the BUILT v2.2.2 APK:

```text
https://raw.githubusercontent.com/
michaeljbriggs86-ctrl/Grassroots-Club-Hub
/main/data/directory.json
/main/data/results.json
```

Native access in that build is constrained to HTTPS, the exact host/repository/path,
GET-only static feed requests, and redirect revalidation.

**Security-review status — checked 2026-09-19:** evidence that a separate deliberate
native-bridge security review was completed has **not been verified**. The presence
of the allowlist in source or a BUILT APK proves implementation, not security
approval. Do not describe this allowlist as "approved" until that review evidence
is produced or Mike explicitly records the decision after review.

## 9.1 Directory

Status on 2026-09-19:

```text
BUILT
DEPLOYED-LIVE: NOT VERIFIED
```

Evidence: inspected v2.2.2 APK contains `assets/static-feed-overlay.js`, the
`index.html` reference, the exact raw GitHub paths and the 2.2.2 native marker.

## 9.2 Standings

Status on 2026-09-19:

```text
BUILT
DEPLOYED-LIVE: NOT VERIFIED
```

Same inspected v2.2.2 APK evidence applies.

## 9.3 Fixtures

Status on 2026-09-19:

```text
PLANNED static cutover
```

The built 2.2.2 app intentionally retains the live fixture fallback until real
populated markup is verified.

## 9.4 Published results

Status on 2026-09-19:

```text
PLANNED static cutover
```

The built 2.2.2 app intentionally retains the live published-results fallback
until real populated U12+ markup is verified.

## 9.5 No dual-authority overwrite

Static directory/standings state must not later be overwritten by legacy live
Android polling. Temporary fixture/result fallbacks must remain isolated.

---

# 10. Build and release pipeline state — checked 2026-09-19

Two APK workflows were able to build on the same commit. This caused a real
release-authority split.

Observed evidence:

```text
Legacy APK artifact downloaded as Grassroots-Club-Hub-APK (11).zip
→ inner app marker: GrassrootsClubHub/2.2.1
→ assets/static-feed-overlay.js: absent
→ index.html overlay reference: absent

Separate static-feed artifact
→ GrassrootsClubHub/2.2.2
→ assets/static-feed-overlay.js: present
→ index.html overlay reference: present
```

Therefore:

- the static-feed implementation is **BUILT**;
- the old 2.2.1 build is also **BUILT**;
- which build is **DEPLOYED-LIVE** is not verified here;
- no document may call directory/standings cutover live until the actual
  distributed/installed artifact is inspected.

Release-pipeline consolidation is **PLANNED**. There must be one authoritative APK
release workflow and an artifact-verification gate before release.

---

# 11. Known open items

1. **PLANNED** — consolidate APK release to one authoritative workflow.
2. **PLANNED** — verify the exact APK distributed/installed after cutover.
3. **PLANNED** — capture populated Selkent fixture markup and test parser.
4. **PLANNED** — capture populated U12+ published-result markup and test parser.
5. **PLANNED** — spot-check a real non-zero standings table when available.
6. **PLANNED** — complete separate defence-in-depth review of backend access
   surfaces already identified in security notes.

---

# 11. Legal/documentation working-copy conflict

Checked 2026-09-19.

`PLANNED - Privacy Policy Working Copy - U15 ACCESS CONFLICT` states that players
do not have app access at any age. The current backend/app design permits player
access for U15 squads only. These are conflicting product/legal statements.

Status:

```text
PLANNED — resolution required before legal publication/deployment
```

No unilateral choice has been made about whether the product behaviour or the
policy wording should change. Mike must decide, informed by legal/privacy review.

`PLANNED - Data Processing Agreement Working Copy` is also a working draft and
must not be represented as a final/deployed agreement.

---

# 12. Architectural principles

1. One intended authority per data category.
2. Public Selkent data may live in static GitHub JSON.
3. Private club/player/safeguarding data stays in Supabase.
4. U7-U11 public results/standings remain excluded.
5. Do not invent provider identifiers.
6. Do not invent league positions or tiebreak rules.
7. Dynamic provider discovery is preferred to hardcoded age IDs.
8. Synthetic data must remain unmistakably synthetic.
9. Failed scrapes must not destroy known-good public data.
10. GitHub, Supabase and Android must not become silent competing authorities.
11. Do not remove a migration fallback until replacement coverage is verified.
12. Status claims must follow `AI-COLLABORATION-PROTOCOL.md` and be dated.
13. Source code must remain readable source code; do not embed source as base64 in
    CI/workflow files.
14. Inspect the actual artifact before claiming BUILT or DEPLOYED-LIVE.

---

# Changelog

## 2026-09-19 — Protocol reconciliation

Applied `AI-COLLABORATION-PROTOCOL.md` to the governing architecture.

Corrected the Android static-feed claim from an undifferentiated
“authoritative/live” state to:

```text
directory: BUILT; DEPLOYED-LIVE not verified
standings: BUILT; DEPLOYED-LIVE not verified
fixtures static cutover: PLANNED
published-results static cutover: PLANNED
```

Recorded artifact hashes and the 2.2.1/2.2.2 build-pipeline split.

The earlier `TODO-SYNC-INTEGRATION.md` planning document is superseded and must not
be used as current status.
