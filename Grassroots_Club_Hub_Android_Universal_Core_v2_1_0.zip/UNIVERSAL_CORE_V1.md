# Grassroots Club Hub — Universal Core v1

This branch/build is intentionally separate from the Shooters Hill production APK.

## What moved out of hard-coded app logic

- Club display name, short name and colours
- Club badge asset / URL
- Current season
- Primary competition provider
- Published-results age rules
- Player-account age rules
- Match format, players on pitch, registered squad cap, matchday cap and rolling-substitution rule per age group
- Enabled player-stat categories per age group
- Club/team list for returning PIN login

## Provider architecture

`competition_providers` is the provider boundary. Universal Core v1 supports:

- `selkent` — existing automated Selkent flow
- `manual` — fixtures/results entered directly in the app

Additional providers can be added without changing the team-management core.

## Tenants created

### Shooters Hill AFC
- Green / white
- Selkent provider
- Results published U12+
- Player accounts U15 only
- Existing 15 teams and current rules preserved

### Greenwich United FC (demo tenant)
- Blue / yellow
- Manual provider
- Results published U11+
- Player accounts disabled
- Different squad limits
- 4 demo teams

The debug APK exposes both via Quick Test. Cloud writes remain disabled in test mode.

## Data isolation

The new configuration tables use club-scoped RLS. Existing `teams` policy also remains club-scoped. The anonymous login directory exposes only club names/colours and team labels needed to route a returning PIN login; it does not expose players, parents, results, team state, notes or messages.

## Next milestone

Universal Core v2 should add the self-service club onboarding wizard and Club Admin configuration editor so a new club can create itself without a database migration.
