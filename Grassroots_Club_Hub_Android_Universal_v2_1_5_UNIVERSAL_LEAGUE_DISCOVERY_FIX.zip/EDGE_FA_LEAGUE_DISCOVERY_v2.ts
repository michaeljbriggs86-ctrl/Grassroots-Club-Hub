import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json; charset=utf-8"};
const reply=(v:unknown,s=200)=>new Response(JSON.stringify(v),{status:s,headers:cors});
const decode=(s:string)=>s.replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&#39;|&#x27;/gi,"'").replace(/&quot;/gi,'"');
const clean=(s:string)=>decode(String(s||'').replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<[^>]+>/g," ")).replace(/\s+/g," ").trim();
const norm=(s:string)=>clean(s).toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
const FA_URL='https://www.thefa.com/about-football-association/who-we-are/county-fas';

const KNOWN_COUNTIES=[
  'AMATEUR FOOTBALL ALLIANCE','ARMY FA','BEDFORDSHIRE FA','BERKS & BUCKS FA','BIRMINGHAM FA','CAMBRIDGESHIRE FA','CHESHIRE FA','CORNWALL FA','CUMBERLAND FA','DERBYSHIRE FA','DEVON FA','DORSET FA','DURHAM FA','EAST RIDING FA','ESSEX FA','GLOUCESTERSHIRE FA','GUERNSEY FA','HAMPSHIRE FA','HEREFORDSHIRE FA','HERTFORDSHIRE FA','HUNTINGDONSHIRE FA','ISLE OF MAN FA','JERSEY FA','KENT FA','LANCASHIRE FA','LEICESTERSHIRE & RUTLAND FA','LINCOLNSHIRE FA','LIVERPOOL FA','LONDON FA','MANCHESTER FA','MIDDLESEX FA','NORFOLK FA','NORTHAMPTONSHIRE FA','NORTH RIDING FA','NORTHUMBERLAND FA','NOTTINGHAMSHIRE FA','OXFORDSHIRE FA','RAF FA','ROYAL NAVY FA','SHEFFIELD & HALLAMSHIRE FA','SHROPSHIRE FA','SOMERSET FA','STAFFORDSHIRE FA','SUFFOLK FA','SURREY FA','SUSSEX FA','WESTMORLAND FA','WEST RIDING FA','WILTSHIRE FA','WORCESTERSHIRE FA'
];
const KNOWN_BY_KEY=new Map(KNOWN_COUNTIES.map(n=>[norm(n),n]));

const CUSTOM_LEAGUES=[
  {
    id:'selkent',
    name:'South-East London & Kent Youth Football League (Selkent Youth League)',
    aliases:['selkent','south east london kent youth league','south-east london & kent youth football league'],
    county_fas:['london fa'],
    provider:'selkent',
    url:'https://www.selkent.org.uk/'
  }
];

const COUNTY_ALIASES:Record<string,string[]>={
  'amateur football alliance':['amateur','london'],
  'berks bucks fa':['berks','bucks','berkshire','buckinghamshire'],
  'east riding fa':['east riding','hull'],
  'isle of man fa':['isle of man'],
  'leicestershire rutland fa':['leicestershire','rutland','leicester'],
  'north riding fa':['north riding'],
  'sheffield hallamshire fa':['sheffield','hallamshire'],
  'west riding fa':['west riding','yorkshire'],
  'royal air force fa':['raf','royal air force'],
  'royal navy fa':['royal navy','navy']
};

async function getFixed(url:string){
  const r=await fetch(url,{headers:{"User-Agent":"Mozilla/5.0 GrassrootsClubHub/2.1.5","Accept":"text/html,application/xhtml+xml"},redirect:'follow'});
  if(!r.ok)throw new Error(`Source returned HTTP ${r.status}`);
  return{html:await r.text(),url:r.url};
}

function contextName(context:string){
  const tags=[...context.matchAll(/<(?:h2|h3|h4|h5|strong)\b[^>]*>([\s\S]*?)<\/(?:h2|h3|h4|h5|strong)>/gi)].map(m=>clean(m[1])).filter(Boolean);
  const usable=tags.filter(n=>n.length>2&&n.length<110&&!/^(website|email|phone|tel|address|contact|chairperson|chief executive|ceo|county fas?)(?:\s*:|$)/i.test(n));
  for(let i=usable.length-1;i>=0;i--){if(/\b(?:FA|FOOTBALL|ASSOCIATION)\b/i.test(usable[i]))return usable[i];}
  return usable.at(-1)||'';
}

function canonicalCountyName(name:string){
  let s=clean(name).replace(/^.*?(?=(?:AMATEUR FOOTBALL ALLIANCE|ARMY FA|[A-Z][A-Z &.'-]+\sFA)\b)/,'').trim();
  s=s.replace(/\s+/g,' ').replace(/^(?:DEVON CFA|SURREY CFA|LONDON CFA|NORFOLK CFA)\s*/i,'').trim();
  if(!s)return'';
  if(/^amateur football alliance$/i.test(s))return'AMATEUR FOOTBALL ALLIANCE';
  return s.toUpperCase();
}

function parseCounties(html:string){
  const websiteByName=new Map<string,any>();
  for(const m of html.matchAll(/<a\b[^>]*href=["'](https?:\/\/[^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi)){
    let u:URL;try{u=new URL(decode(m[1]));}catch{continue;}
    const host=u.hostname.toLowerCase().replace(/^www\./,'');
    if(/(?:thefa\.com|englandfootball\.com|wembleystadium\.com|facebook\.com|instagram\.com|youtube\.com|tiktok\.com|twitter\.com|x\.com)$/.test(host))continue;
    const ctx=html.slice(Math.max(0,(m.index||0)-2000),m.index||0);
    const raw=canonicalCountyName(contextName(ctx));
    let official=KNOWN_BY_KEY.get(norm(raw));
    if(!official){
      // Some page blocks contain presentation text before the County FA name.
      const ctxKey=norm(clean(ctx));
      official=KNOWN_COUNTIES.find(n=>ctxKey.endsWith(norm(n))||ctxKey.includes(' '+norm(n)+' '));
    }
    if(!official)continue;
    const key=norm(official);
    const candidate={name:official,website:u.origin+(u.pathname==='/'?'':u.pathname),host};
    const current=websiteByName.get(key);
    if(!current||host.includes('fa'))websiteByName.set(key,candidate);
  }
  // Always return the canonical County FA list once The FA directory has loaded.
  // This prevents duplicate entries when a County FA block contains several links.
  return KNOWN_COUNTIES.map(name=>websiteByName.get(norm(name))||{name,website:'',host:''});
}

function parseLeagueLinks(html:string,base:string){
  const out:any[]=[];const seen=new Set<string>();
  for(const m of html.matchAll(/<a\b[^>]*href=["']([^"']*(?:index\.html|Index\.do)\?[^"']*league=(\d+)[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi)){
    const id=m[2],name=clean(m[3]);if(!name||name.length>180||seen.has(id))continue;
    let url='';try{url=new URL(decode(m[1]),base).toString();}catch{continue;}
    seen.add(id);out.push({id,name,url,provider:'fulltime',source:'FA Full-Time'});
  }
  return out;
}

async function leaguePage(initial:string){
  const root=`https://fulltime.thefa.com/home/leagues/${encodeURIComponent(initial)}.html`;
  const first=await getFixed(root);let rows=parseLeagueLinks(first.html,first.url);let max=1;
  const escaped=initial.replace(/[-/\\^$*+?.()|[\]{}]/g,'\\$&');
  const rx=new RegExp(`/home/leagues/${escaped}/(\\d+)\\.html`,'gi');
  for(const m of first.html.matchAll(rx))max=Math.max(max,Number(m[1])||1);
  max=Math.min(max,12);
  for(let p=2;p<=max;p++){
    try{const r=await getFixed(`https://fulltime.thefa.com/home/leagues/${encodeURIComponent(initial)}/${p}.html`);rows=rows.concat(parseLeagueLinks(r.html,r.url));}catch{}
  }
  return rows;
}

function countyTerms(countyFa:string){
  const key=norm(countyFa);
  if(COUNTY_ALIASES[key])return COUNTY_ALIASES[key];
  const stripped=key.replace(/\b(?:county|football|association|fa)\b/g,' ').replace(/\s+/g,' ').trim();
  return stripped.split(/\s+/).filter(t=>t.length>=4);
}

function customLeagues(query:string,countyFa:string){
  const q=norm(query),county=norm(countyFa);
  return CUSTOM_LEAGUES.filter(l=>{
    const countyOk=!county||l.county_fas.some(c=>norm(c)===county);
    const searchOk=!q||norm(l.name).includes(q)||l.aliases.some(a=>norm(a).includes(q)||q.includes(norm(a)));
    return countyOk&&searchOk;
  }).map(l=>({id:l.id,name:l.name,url:l.url,provider:l.provider,source:'League website'}));
}

async function countyLeagues(countyFa:string){
  const terms=countyTerms(countyFa);
  const initials=new Set<string>();
  for(const t of terms){if(/^[a-z]/.test(t))initials.add(t[0].toUpperCase());}
  let rows:any[]=[];
  for(const initial of initials){try{rows=rows.concat(await leaguePage(initial));}catch{}}
  const seen=new Set<string>();
  rows=rows.filter(r=>{if(seen.has(r.id))return false;seen.add(r.id);const n=norm(r.name);return terms.some(t=>n.includes(norm(t)));});
  const customs=customLeagues('',countyFa);
  return [...customs,...rows].slice(0,60);
}

async function searchLeagues(query:string,countyFa:string=''){
  const q=norm(query);if(q.length<2)throw new Error('Type at least 2 letters of the league name');
  const terms=q.split(/\s+/).filter(Boolean),countyTermsList=countyTerms(countyFa);
  const initials=new Set<string>();
  if(/^[a-z]/.test(q))initials.add(q[0].toUpperCase());
  for(const t of countyTermsList){if(/^[a-z]/.test(t))initials.add(t[0].toUpperCase());}
  if(!initials.size)initials.add('0-9');
  let rows:any[]=[];
  for(const initial of initials){try{rows=rows.concat(await leaguePage(initial));}catch{}}
  const seen=new Set<string>();
  const scored=rows.filter(r=>{if(seen.has(r.id))return false;seen.add(r.id);return true;}).map(r=>{
    const n=norm(r.name);let score=0;
    if(n.includes(q))score+=120;
    for(const t of terms)if(n.includes(t))score+=20;
    if(countyTermsList.some(t=>n.includes(norm(t))))score+=35;
    return{...r,_score:score};
  }).filter(r=>r._score>=Math.max(20,terms.length*20)).sort((a,b)=>b._score-a._score||a.name.localeCompare(b.name)).map(({_score,...r})=>r);
  const customs=customLeagues(q,countyFa);
  return [...customs,...scored.filter(r=>!customs.some(c=>norm(c.name)===norm(r.name)))].slice(0,60);
}

Deno.serve(async(req:Request)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  if(req.method!=='POST')return reply({error:'Method not allowed'},405);
  try{
    const b=await req.json();const action=String(b?.action||'');
    if(action==='counties'){
      const p=await getFixed(FA_URL);
      return reply({source_url:FA_URL,counties:parseCounties(p.html)});
    }
    if(action==='county_leagues'){
      const county=String(b?.county_fa||'').trim();if(!county)throw new Error('Choose a County FA first');
      return reply({directory_url:'https://fulltime.thefa.com/home/leagues.html',county_fa:county,leagues:await countyLeagues(county)});
    }
    if(action==='league_search'){
      const county=String(b?.county_fa||'').trim();
      return reply({directory_url:'https://fulltime.thefa.com/home/leagues.html',county_fa:county,leagues:await searchLeagues(String(b?.query||''),county)});
    }
    return reply({error:'Unsupported action'},400);
  }catch(e){return reply({error:e instanceof Error?e.message:String(e)},502);}
});
