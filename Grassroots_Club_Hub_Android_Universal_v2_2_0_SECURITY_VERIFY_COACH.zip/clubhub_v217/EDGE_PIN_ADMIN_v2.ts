// Deployed live as Supabase Edge Function pin-admin v2.
// JWT-protected: creates/changes a parent's 6-digit PIN and lets coaching staff issue a temporary reset PIN.
