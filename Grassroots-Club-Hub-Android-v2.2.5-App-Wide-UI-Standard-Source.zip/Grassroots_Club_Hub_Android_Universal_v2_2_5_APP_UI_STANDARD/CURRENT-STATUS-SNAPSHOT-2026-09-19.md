# Current Master Status Manifest — Grassroots Club Hub
















**Checked:** 2026-09-19  
**Governing protocol:** `AI-COLLABORATION-PROTOCOL.md`
















This file is the quick index for the canonical master folder. It does not replace
`ARCHITECTURE.md`.
















## Canonical documents
















- `AI-COLLABORATION-PROTOCOL.md` — current collaboration rules.
- `ARCHITECTURE.md` — current architecture/source-of-truth register.
- `CURRENT-STATUS-MANIFEST.md` — this index.
- `APP-UI-DESIGN-GUIDELINES.md` — governing app-wide UI standard; no deviations without explicit approval.
















## Android

### v2.2.5 app-wide UI standard source

Status: **WRITTEN + TESTED at source level** — checked 2026-09-19.

Canonical UI authority:

`APP-UI-DESIGN-GUIDELINES.md`

Design marker: `approved-app-ui-2026-09-19-v1`

Source changes include generated raster football imagery in place of constructed auth football/goal SVG scenes, app-wide shared UI tokens/components, and responsive rules for small phones through tablets/landscape. 31/31 source checks passed, plus JavaScript syntax and CSS structural checks.

**v2.2.5 APK: NOT YET BUILT / NOT YET INSPECTED. DEPLOYED-LIVE: NOT CLAIMED.**

The v2.2.4 APK remains the latest inspected BUILT artifact until v2.2.5 is built and inspected.

















### v2.2.4 mock-up-exact login UI source and APK


Status: **BUILT** — source and APK checked 2026-09-19.


Canonical source archive:


`CURRENT - Grassroots-Club-Hub-Android-v2.2.4-Mockup-Exact-UI-Source.zip`


```text
Source ZIP SHA-256:
e73bf590d78876c0953de51e71a00285492b44bc0481615e086eab8b918479c2


APK SHA-256:
14b4abd74c94b6902fabedaed84f2a647b83824d11753554abf21c16b55f7f44
```


Evidence:
- source ZIP passed 23/23 mock-up/UI structural checks and syntax checks;
- GitHub root ZIP is byte-identical to the canonical Drive ZIP;
- run `35454187954` built and uploaded an APK from that exact source;
- direct APK inspection found the v2.2.4 native marker, design revision
  `approved-mockup-2026-09-19-v1`, and the static-feed overlay;
- the APK still contains obsolete `activateAssignment()`.


Build evidence: `BUILD-VERIFICATION-v2.2.4.md`.


The reusable U15 player-code migration/Edge Function is still only
**WRITTEN / NOT DEPLOYED**, so Player Access is not yet end-to-end live.


v2.2.4 is **BUILT**. **DEPLOYED-LIVE — NOT VERIFIED**.


### v2.2.2 static-feed APK — previous verified BUILT Android artifact
















Status: **BUILT** — verified by artifact inspection on 2026-09-19.
















```text
APK SHA-256:
c38dea003e8f5f2342188fd5afa806b744cdf9a3275a2788aa4db09d5d84e246
```
















Static directory and U12+ standings integration are **BUILT**.
















Status: **DEPLOYED-LIVE — NOT VERIFIED**.
















Native allowlist security review: **NOT VERIFIED** as of 2026-09-19. The exact
GitHub Raw allowlist is present in the BUILT artifact, but no separate deliberate
security-review evidence has been produced.
















### Legacy APK (11)
















Status: **BUILT** legacy 2.2.1 artifact.
















```text
ZIP SHA-256:
1e4bf9565683c9f7edf9be6afdb1719a8fcd83c84190381c62bc53e95adeda5d
















inner APK SHA-256:
b18199a2fb9de325d3353254fbacdeb07faaa973920c31be244300937c88455f
```
















It does not contain `static-feed-overlay.js` and is retained only as historical
evidence in the archive.
















## Backend
















Status: **DEPLOYED-LIVE** — last verified 2026-09-18 by the live backend export.
















Legacy SQL/Edge files are **WRITTEN** historical references only.
















## Obsolete planning documents
















`TODO-SYNC-INTEGRATION.md` is superseded. Its old “PLANNED” status no longer
describes the Android 2.2.2 source because that integration is now **BUILT**.
The TODO is retained in the archive only for provenance.
















## Release pipeline


Status: **PLANNED / NOT CONSOLIDATED** — checked 2026-09-19.


Two APK workflows still exist and both triggered on the v2.2.4 source commit.


- `build-apk-static-feed.yml` is now readable, v2.2.4-aware and contains no
  base64-embedded source. Its Android build succeeds, but run `35454187950` fails
  the artifact gate because it checks only `classes.dex`; the native marker is in
  `classes2.dex`.
- legacy `build-apk.yml` run `35454187954` succeeds and produced the inspected
  v2.2.4 APK. That proves the app is BUILT, but this workflow remains selected for
  retirement because it competes with the intended verified release path.
- Fix the multidex verifier, successfully upload/inspect the candidate workflow's
  APK, then delete/retire `build-apk.yml`.
- The source ZIP's stale `build-apk-static-feed.REPLACEMENT.yml` sidecar still
  targets v2.2.2/2202 and should be removed or refreshed.
- GitHub writes from the current integration return HTTP 403, including ordinary
  fixture-file creation, so these repository mutations cannot currently be made
  from this connection.
- Canonical Drive and GitHub-root `ARCHITECTURE.md` differ and need reconciliation.


Legacy `activateAssignment()` cleanup remains **PLANNED** and is confirmed present
in the BUILT v2.2.4 APK.


## Legal/privacy working documents
















Status: **PLANNED** — product direction decided 2026-09-19; legal publication is
not verified.
















Mike explicitly confirmed retaining restricted U15 player access, with no access
for younger players and with safeguarding/legal-compliance protections in place.
The Privacy Policy working copy has been updated to match that decision and is
titled `PLANNED - Privacy Policy Working Copy - U15 PLAYER ACCESS`.
















The previous product-policy conflict is resolved. The Privacy Policy and DPA remain
working copies with placeholders/review still outstanding and must not be described
as final or DEPLOYED-LIVE legal documents.