// Deployed Supabase edge function reference.
// Universal PIN identities use GCH-PIN!<6-digit-pin>#APP.
// The live pin-login function also accepts the legacy credential format for existing accounts during migration.
